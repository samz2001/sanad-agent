"""
PDF -> RAG-ready JSON converter for Saudi MHRSD labor/employment regulatory documents.

Design notes (validated against real sample documents before writing this):
- Text extraction uses PyMuPDF (fitz) page.get_text(). pdfplumber's word-level
  extraction was tested and produces character-scrambled Arabic (visual order,
  not logical order); PyMuPDF's get_text() was verified correct on Arabic RTL
  pages and is used for ALL text extraction in this pipeline.
- Table detection uses fitz's find_tables(strategy="lines_strict"), which
  requires actual ruling lines. The default whitespace-based strategy was
  tested and produces heavy false positives (lettered/numbered lists and
  justified paragraphs get misdetected as tables). lines_strict was verified
  against both a genuine bordered table and several false-positive cases.
- Table CELL text is re-extracted via page.get_text(clip=cell_bbox) rather
  than table.extract(), because the latter has the same Arabic scrambling
  bug. Cell bboxes from Table.cells are stored COLUMN-MAJOR (verified by
  inspection), not row-major -- indexing uses idx = col * row_count + row.
- Section/chunk unit: "article" boundaries are detected via regex for
  Arabic (\u0627\u0644\u0645\u0627\u062f\u0629 <ordinal>) and English
  ("Article (N)" / "Article N:") patterns, since that's the citable unit in
  these documents. If too few matches are found, falls back to font-size
  based heading detection, then to paragraph-level chunking as a last resort.
"""

import fitz  # PyMuPDF
import json
import re
import sys
import unicodedata
from pathlib import Path

# ---------------------------------------------------------------------------
# Text normalization
# ---------------------------------------------------------------------------

ARABIC_INDIC_DIGITS = str.maketrans("٠١٢٣٤٥٦٧٨٩", "0123456789")


def normalize_text(text: str) -> str:
    if text is None:
        return text
    text = unicodedata.normalize("NFC", text)
    text = text.translate(ARABIC_INDIC_DIGITS)
    # Collapse excessive whitespace but keep paragraph breaks
    text = re.sub(r"[ \t]+", " ", text)
    text = re.sub(r"\n{3,}", "\n\n", text)
    return text.strip()


def detect_language(text: str) -> str:
    if not text:
        return "unknown"
    arabic_chars = len(re.findall(r"[\u0600-\u06FF]", text))
    latin_chars = len(re.findall(r"[A-Za-z]", text))
    if arabic_chars == 0 and latin_chars == 0:
        return "unknown"
    if arabic_chars > latin_chars * 2:
        return "ar"
    if latin_chars > arabic_chars * 2:
        return "en"
    return "mixed"


# ---------------------------------------------------------------------------
# Article / section boundary detection
# ---------------------------------------------------------------------------

ARABIC_ARTICLE_PATTERN = re.compile(
    r"(?:^|\n)\s*المادة\s+((?:ال)?[\u0621-\u064A]+(?:\s+وال[\u0621-\u064A]+)*)\s*[:\.]"
)
ENGLISH_ARTICLE_PATTERN = re.compile(
    r"(?:^|\n)\s*Article\s*[\(\s]?(\d+)[\)\.]?[:\s]", re.IGNORECASE
)


def find_article_boundaries(full_text: str):
    """Returns a list of (match_start, match_end, label) for article headings."""
    matches = []
    for m in ARABIC_ARTICLE_PATTERN.finditer(full_text):
        matches.append((m.start(), m.end(), f"المادة {m.group(1)}"))
    for m in ENGLISH_ARTICLE_PATTERN.finditer(full_text):
        matches.append((m.start(), m.end(), f"Article ({m.group(1)})"))
    matches.sort(key=lambda x: x[0])
    return matches


def find_heading_boundaries(doc):
    """Fallback: detect headings via font size (larger than page-median body text)."""
    all_sizes = []
    lines_info = []  # (page_index, y0, text, size)
    for pno, page in enumerate(doc):
        d = page.get_text("dict")
        for block in d.get("blocks", []):
            for line in block.get("lines", []):
                spans = line.get("spans", [])
                if not spans:
                    continue
                text = "".join(s["text"] for s in spans).strip()
                if not text:
                    continue
                size = max(s["size"] for s in spans)
                all_sizes.append(size)
                lines_info.append((pno, line["bbox"][1], text, size))
    if not all_sizes:
        return []
    all_sizes.sort()
    median_size = all_sizes[len(all_sizes) // 2]
    headings = []
    for pno, y0, text, size in lines_info:
        if size >= median_size * 1.25 and len(text) < 120:
            headings.append((pno, text))
    return headings


# ---------------------------------------------------------------------------
# Table extraction
# ---------------------------------------------------------------------------

def extract_table_cells(page, table):
    """Re-extract cell text via clipped get_text (correct Arabic order),
    correcting for the fact that Table.cells is column-major."""
    rows, cols = table.row_count, table.col_count
    cells = table.cells
    grid = []
    for r in range(rows):
        row_vals = []
        for c in range(cols):
            idx = c * rows + r
            bbox = cells[idx] if idx < len(cells) else None
            if bbox is None:
                row_vals.append(None)
                continue
            txt = page.get_text(clip=fitz.Rect(bbox)).strip()
            txt = txt.replace("\n", " ")
            row_vals.append(normalize_text(txt) if txt else None)
        grid.append(row_vals)
    return grid


def rows_to_markdown(rows):
    if not rows:
        return ""
    lines = []
    header = rows[0]
    lines.append("| " + " | ".join(c or "" for c in header) + " |")
    lines.append("|" + "|".join(["---"] * len(header)) + "|")
    for row in rows[1:]:
        lines.append("| " + " | ".join(c or "" for c in row) + " |")
    return "\n".join(lines)


def estimate_table_offset(table, page_start_offset, page_text_len, page_height):
    """Estimate a table's position in the full-text character-offset space,
    based on its vertical position on the page. Approximate but sufficient
    to disambiguate which section (of possibly several sharing one page)
    a table belongs to -- avoids attaching the same table to every section
    that happens to overlap the table's page."""
    if page_height <= 0 or page_text_len == 0:
        return page_start_offset
    y0 = table.bbox[1]
    fraction = max(0.0, min(1.0, y0 / page_height))
    return page_start_offset + int(fraction * page_text_len)


def assign_tables_to_boundaries(table_candidates, boundaries):
    """table_candidates: list of (estimated_offset, table_dict)
    boundaries: list of (start_offset, end_offset) per section, in order.
    Returns dict: section_index -> [table_dict, ...], each table assigned
    to exactly one section."""
    assigned = {}
    for offset, table_dict in table_candidates:
        target_idx = len(boundaries) - 1
        for idx, (start, end) in enumerate(boundaries):
            if start <= offset < end:
                target_idx = idx
                break
        assigned.setdefault(target_idx, []).append(table_dict)
    return assigned


def extract_tables_for_page(page, page_number, document_id, errors_out):
    """Detect and extract genuine (bordered) tables on a page."""
    results = []
    try:
        found = page.find_tables(strategy="lines_strict")
    except Exception as e:
        errors_out.append({
            "page": page_number,
            "reason": f"table detection raised an exception: {e}",
        })
        return results

    for i, table in enumerate(found.tables):
        try:
            grid = extract_table_cells(page, table)
            # Sanity check: a real table must have at least 2 rows and
            # at least one non-empty cell per row on average.
            non_empty = sum(1 for row in grid for cell in row if cell)
            if len(grid) < 2 or non_empty == 0:
                errors_out.append({
                    "page": page_number,
                    "reason": f"table {i} detected but extraction produced no usable content",
                })
                continue
            results.append({
                "table_id": f"{document_id}_p{page_number}_t{i}",
                "page": page_number,
                "bbox": list(table.bbox),
                "rows": grid,
                "markdown": rows_to_markdown(grid),
            })
        except Exception as e:
            errors_out.append({
                "page": page_number,
                "reason": f"table {i} extraction failed: {e}",
            })
    return results


# ---------------------------------------------------------------------------
# Main per-document pipeline
# ---------------------------------------------------------------------------

def _looks_like_junk_title(text: str) -> bool:
    """PDF metadata titles are often leftover export artifacts
    (e.g. 'Microsoft Word - filename.docx') rather than the real
    document title -- verified on sample corpus. Reject those."""
    lowered = text.lower()
    junk_markers = (".doc", ".docx", ".pdf", "microsoft word", "untitled")
    return any(marker in lowered for marker in junk_markers)


def guess_title(doc, fallback_name: str) -> str:
    meta_title = (doc.metadata or {}).get("title", "").strip()
    if meta_title and not _looks_like_junk_title(meta_title):
        return normalize_text(meta_title)

    # The document's real title is usually the largest-font text on page 1
    # (cover pages often list decree/amendment history in body-sized text
    # ABOVE the title, so "first line" is unreliable -- verified on sample).
    if len(doc) > 0:
        d = doc[0].get_text("dict")
        best_text, best_size = None, 0
        for block in d.get("blocks", []):
            for line in block.get("lines", []):
                spans = line.get("spans", [])
                if not spans:
                    continue
                text = "".join(s["text"] for s in spans).strip()
                if not text or len(text) > 150:
                    continue
                size = max(s["size"] for s in spans)
                if size > best_size:
                    best_size, best_text = size, text
        if best_text:
            return normalize_text(best_text)

    return fallback_name


def offset_to_page(offset, page_offsets):
    page = 1
    for start, pno in page_offsets:
        if start <= offset:
            page = pno
        else:
            break
    return page


def process_pdf(pdf_path: str, document_id: str, drive_file_id: str = None) -> dict:
    doc = fitz.open(pdf_path)
    fallback_name = Path(pdf_path).stem
    title = guess_title(doc, fallback_name)

    # Build full text with page-offset map
    page_texts = []
    page_offsets = []  # (char_offset_of_page_start, page_number)
    full_text = ""
    for i, page in enumerate(doc):
        page_offsets.append((len(full_text), i + 1))
        t = page.get_text()
        page_texts.append(t)
        full_text += t + "\n"

    language = detect_language(full_text)

    extraction_errors = []

    # Extract all genuine tables. Also build a flat list of
    # (estimated_char_offset, table_dict) candidates for later assignment
    # to exactly one section -- avoids duplicating a table into every
    # section that happens to overlap its page.
    table_candidates = []
    for i, page in enumerate(doc):
        page_errors = []
        page_start_offset = page_offsets[i][0]
        page_height = page.rect.height
        tabs = extract_tables_for_page(page, i + 1, document_id, page_errors)
        for t in tabs:
            # table.bbox was stored as a list on the dict; reconstruct a
            # lightweight object with .bbox for the offset estimator
            class _B:
                pass
            b = _B()
            b.bbox = t["bbox"]
            offset = estimate_table_offset(b, page_start_offset, len(page_texts[i]), page_height)
            table_candidates.append((offset, t))
        for err in page_errors:
            extraction_errors.append({
                "document": Path(pdf_path).name,
                "title": title,
                "page": err["page"],
                "reason": err["reason"],
            })

    # --- Determine sectioning strategy ---
    article_matches = find_article_boundaries(full_text)
    sections = []

    if len(article_matches) >= 2:
        section_type = "article"
        raw_boundaries = article_matches  # (start, end_of_heading, label)
        char_ranges = []
        for idx, (start, end, label) in enumerate(raw_boundaries):
            text_end = raw_boundaries[idx + 1][0] if idx + 1 < len(raw_boundaries) else len(full_text)
            char_ranges.append((start, text_end))
        tables_by_section = assign_tables_to_boundaries(table_candidates, char_ranges)

        for idx, (start, end, label) in enumerate(raw_boundaries):
            text_start = end
            text_end = raw_boundaries[idx + 1][0] if idx + 1 < len(raw_boundaries) else len(full_text)
            raw_text = full_text[text_start:text_end].strip()
            page_start = offset_to_page(start, page_offsets)
            page_end = offset_to_page(max(text_end - 1, text_start), page_offsets)

            section = {
                "section_id": f"{document_id}_art_{idx + 1}",
                "type": section_type,
                "label": label,
                "sequence_number": idx + 1,
                "page_start": page_start,
                "page_end": page_end,
                "text": normalize_text(raw_text),
            }
            section_tables = tables_by_section.get(idx, [])
            if section_tables:
                section["tables"] = section_tables
            sections.append(section)

    else:
        # Fallback 1: font-size heading detection
        headings = find_heading_boundaries(doc)
        if len(headings) >= 2:
            section_type = "heading_section"
            boundaries_raw = []
            for pno, text in headings:
                page_start_offset = page_offsets[pno][0] if pno < len(page_offsets) else len(full_text)
                idx_in_page = page_texts[pno].find(text)
                offset = page_start_offset + (idx_in_page if idx_in_page >= 0 else 0)
                boundaries_raw.append((offset, text))
            boundaries_raw.sort(key=lambda x: x[0])

            char_ranges = []
            for idx, (start, label) in enumerate(boundaries_raw):
                text_end = boundaries_raw[idx + 1][0] if idx + 1 < len(boundaries_raw) else len(full_text)
                char_ranges.append((start, text_end))
            tables_by_section = assign_tables_to_boundaries(table_candidates, char_ranges)

            for idx, (start, label) in enumerate(boundaries_raw):
                text_end = boundaries_raw[idx + 1][0] if idx + 1 < len(boundaries_raw) else len(full_text)
                raw_text = full_text[start:text_end].strip()
                page_start = offset_to_page(start, page_offsets)
                page_end = offset_to_page(max(text_end - 1, start), page_offsets)
                section = {
                    "section_id": f"{document_id}_sec_{idx + 1}",
                    "type": section_type,
                    "label": normalize_text(label),
                    "sequence_number": idx + 1,
                    "page_start": page_start,
                    "page_end": page_end,
                    "text": normalize_text(raw_text),
                }
                section_tables = tables_by_section.get(idx, [])
                if section_tables:
                    section["tables"] = section_tables
                sections.append(section)
        else:
            # Fallback 2: paragraph-level chunking per page (finest granularity
            # we have offsets for is per-page, so tables are assigned to the
            # paragraph-range boundary that contains their estimated offset).
            section_type = "paragraph_section"
            para_records = []  # (start_offset, end_offset, page_no, text)
            cursor = 0
            for i, ptext in enumerate(page_texts):
                page_start_offset = page_offsets[i][0]
                paragraphs = [p for p in re.split(r"(\n\s*\n)", ptext)]
                local_offset = page_start_offset
                buf = ""
                buf_start = local_offset
                for chunk in paragraphs:
                    if chunk.strip() == "":
                        if buf.strip():
                            para_records.append((buf_start, local_offset, i + 1, buf))
                        local_offset += len(chunk)
                        buf = ""
                        buf_start = local_offset
                    else:
                        buf += chunk
                        local_offset += len(chunk)
                if buf.strip():
                    para_records.append((buf_start, local_offset, i + 1, buf))

            char_ranges = [(s, e) for s, e, _, _ in para_records]
            tables_by_section = assign_tables_to_boundaries(table_candidates, char_ranges)

            for idx, (start, end, pno, text) in enumerate(para_records):
                section = {
                    "section_id": f"{document_id}_sec_{idx + 1}",
                    "type": section_type,
                    "label": None,
                    "sequence_number": idx + 1,
                    "page_start": pno,
                    "page_end": pno,
                    "text": normalize_text(text),
                }
                section_tables = tables_by_section.get(idx, [])
                if section_tables:
                    section["tables"] = section_tables
                sections.append(section)

    result = {
        "document_id": document_id,
        "source_file": Path(pdf_path).name,
        "drive_file_id": drive_file_id,
        "title": title,
        "language": language,
        "total_pages": len(doc),
        "sectioning_strategy": (
            "article" if len(article_matches) >= 2
            else ("heading_section" if len(sections) and sections[0]["type"] == "heading_section" else "paragraph_section")
        ),
        "sections": sections,
        "extraction_errors": extraction_errors,
    }
    doc.close()
    return result


if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("Usage: python pdf_to_json.py <pdf_path> [document_id] [drive_file_id]")
        sys.exit(1)
    pdf_path = sys.argv[1]
    document_id = sys.argv[2] if len(sys.argv) > 2 else Path(pdf_path).stem
    drive_file_id = sys.argv[3] if len(sys.argv) > 3 else None
    out = process_pdf(pdf_path, document_id, drive_file_id)
    out_path = f"{document_id}.json"
    with open(out_path, "w", encoding="utf-8") as f:
        json.dump(out, f, ensure_ascii=False, indent=2)
    print(f"Wrote {out_path}: {len(out['sections'])} sections, "
          f"{sum(1 for s in out['sections'] if s.get('tables')) } sections with tables, "
          f"{len(out['extraction_errors'])} extraction errors")
