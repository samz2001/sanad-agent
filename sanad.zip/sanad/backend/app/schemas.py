from __future__ import annotations

from typing import Any

from pydantic import BaseModel, Field


class ChatRequest(BaseModel):
    message: str
    session_id: str = "default"
    locale: str = "ar"


class ChatResponse(BaseModel):
    intent: str
    reply: str
    data: dict[str, Any] = {}
    agents: list[str] = []
    citations: list[dict[str, Any]] = []
    trace: list[dict[str, Any]] = []


class CompareRequest(BaseModel):
    analysis_ids: list[str] = Field(min_length=2)
    weights: dict[str, float] | None = None
    locale: str = "ar"


class SalaryRequest(BaseModel):
    job_title: str = ""
    city: str = ""
    offered_salary: float | None = None
    cv_text: str = ""
    locale: str = "ar"


class PreferencesRequest(BaseModel):
    display_name: str | None = None
    locale: str | None = None
    consent_store_contracts: bool | None = None
    priorities: dict[str, float] | None = None


class AskRequest(BaseModel):
    question: str
    locale: str = "ar"
