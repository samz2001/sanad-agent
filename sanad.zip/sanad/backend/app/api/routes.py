from __future__ import annotations

from fastapi import APIRouter, Depends, File, Form, HTTPException, UploadFile
from sqlalchemy.orm import Session

from app.agents.regulatory_rag import RegulatoryRAGAgent
from app.agents.salary_cv import SalaryCVAgent
from app.api.deps import current_user
from app.config import settings
from app.db.database import get_session
from app.db.models import Analysis, Comparison, Document
from app.orchestrator import orchestrator
from app.schemas import (
    AskRequest,
    ChatRequest,
    ChatResponse,
    CompareRequest,
    PreferencesRequest,
    SalaryRequest,
)
from app.services import (
    analyse_document,
    analysis_to_dict,
    compare_analyses,
    get_or_create_user,
    hydrate_facts,
    store_document,
)
from app.tools import file_storage, regulation_checker

router = APIRouter(prefix="/api")

MAX_UPLOAD_BYTES = 15 * 1024 * 1024


@router.get("/health")
def health() -> dict:
    from app.rag.vector_store import get_store

    store = get_store()
    return {
        "status": "ok",
        "mode": "online" if settings.online else "offline",
        "index_ready": store.ready,
        "indexed_chunks": len(store.chunks),
        "embedder": store.embedder.name if store.embedder else None,
    }


# ---------------------------------------------------------------- profile


@router.get("/me")
def me(user_id: str = Depends(current_user), session: Session = Depends(get_session)) -> dict:
    user = get_or_create_user(session, user_id)
    return {
        "id": user.id,
        "display_name": user.display_name,
        "locale": user.locale,
        "consent_store_contracts": user.consent_store_contracts,
        "priorities": user.priorities or {},
    }


@router.put("/me")
def update_me(
    payload: PreferencesRequest,
    user_id: str = Depends(current_user),
    session: Session = Depends(get_session),
) -> dict:
    user = get_or_create_user(session, user_id)
    for field_name, value in payload.model_dump(exclude_none=True).items():
        setattr(user, field_name, value)
    session.commit()
    return me(user_id, session)


# ---------------------------------------------------------------- documents


@router.post("/documents")
async def upload_document(
    file: UploadFile = File(...),
    kind: str = Form("contract"),
    label: str = Form(""),
    consent_store: bool = Form(False),
    analyse: bool = Form(True),
    locale: str = Form("ar"),
    user_id: str = Depends(current_user),
    session: Session = Depends(get_session),
) -> dict:
    data = await file.read()
    if not data:
        raise HTTPException(400, "The uploaded file is empty.")
    if len(data) > MAX_UPLOAD_BYTES:
        raise HTTPException(413, "File is larger than 15 MB.")

    document = store_document(
        session,
        user_id,
        file.filename or "upload",
        data,
        kind=kind,
        mime_type=file.content_type or "",
        label=label,
        keep_file=consent_store,
    )
    if not consent_store:
        # No consent: the original file is never written, only the extracted text
        # needed to answer in this session.
        document.stored_path = ""
        session.commit()

    payload = {
        "id": document.id,
        "kind": document.kind,
        "filename": document.filename,
        "label": document.label,
        "language": document.language,
        "extraction_method": document.extraction_method,
        "characters": len(document.text),
        "stored": bool(document.stored_path),
    }

    if not document.text.strip():
        payload["warning"] = "No text could be read from this file. Try a clearer scan or a PDF with a text layer."
        return payload

    if analyse and kind == "contract":
        cv = (
            session.query(Document)
            .filter(Document.user_id == user_id, Document.kind == "cv")
            .order_by(Document.created_at.desc())
            .first()
        )
        analysis = analyse_document(session, document, cv_text=cv.text if cv else "", locale=locale)
        payload["analysis"] = analysis_to_dict(analysis, document)
        payload["analysis"]["facts"] = hydrate_facts(session, analysis)
    return payload


@router.get("/documents")
def list_documents(
    user_id: str = Depends(current_user), session: Session = Depends(get_session)
) -> list[dict]:
    documents = (
        session.query(Document)
        .filter(Document.user_id == user_id)
        .order_by(Document.created_at.desc())
        .all()
    )
    return [
        {
            "id": d.id,
            "kind": d.kind,
            "filename": d.filename,
            "label": d.label,
            "language": d.language,
            "created_at": d.created_at.isoformat(),
            "stored": bool(d.stored_path),
        }
        for d in documents
    ]


@router.delete("/documents/{document_id}")
def delete_document(
    document_id: str, user_id: str = Depends(current_user), session: Session = Depends(get_session)
) -> dict:
    document = session.get(Document, document_id)
    if document is None or document.user_id != user_id:
        raise HTTPException(404, "Document not found.")
    if document.stored_path:
        file_storage.delete(document.stored_path)
    session.delete(document)
    session.commit()
    return {"deleted": document_id}


@router.post("/documents/{document_id}/analyse")
def analyse(
    document_id: str,
    locale: str = "ar",
    user_id: str = Depends(current_user),
    session: Session = Depends(get_session),
) -> dict:
    document = session.get(Document, document_id)
    if document is None or document.user_id != user_id:
        raise HTTPException(404, "Document not found.")
    cv = (
        session.query(Document)
        .filter(Document.user_id == user_id, Document.kind == "cv")
        .order_by(Document.created_at.desc())
        .first()
    )
    analysis = analyse_document(session, document, cv_text=cv.text if cv else "", locale=locale)
    payload = analysis_to_dict(analysis, document)
    payload["facts"] = hydrate_facts(session, analysis)
    return payload


# ---------------------------------------------------------------- analyses


@router.get("/analyses")
def list_analyses(
    user_id: str = Depends(current_user), session: Session = Depends(get_session)
) -> list[dict]:
    analyses = (
        session.query(Analysis)
        .filter(Analysis.user_id == user_id)
        .order_by(Analysis.created_at.desc())
        .all()
    )
    out = []
    for analysis in analyses:
        document = session.get(Document, analysis.document_id)
        payload = analysis_to_dict(analysis, document)
        payload.pop("findings", None)
        out.append(payload)
    return out


@router.get("/analyses/{analysis_id}")
def get_analysis(
    analysis_id: str, user_id: str = Depends(current_user), session: Session = Depends(get_session)
) -> dict:
    analysis = session.get(Analysis, analysis_id)
    if analysis is None or analysis.user_id != user_id:
        raise HTTPException(404, "Analysis not found.")
    document = session.get(Document, analysis.document_id)
    payload = analysis_to_dict(analysis, document)
    payload["facts"] = hydrate_facts(session, analysis)
    return payload


# ---------------------------------------------------------------- comparison


@router.post("/compare")
def compare(
    payload: CompareRequest,
    user_id: str = Depends(current_user),
    session: Session = Depends(get_session),
) -> dict:
    try:
        comparison = compare_analyses(
            session, user_id, payload.analysis_ids, payload.weights, payload.locale
        )
    except ValueError as exc:
        raise HTTPException(400, str(exc)) from exc
    return {"id": comparison.id, **comparison.result}


@router.get("/comparisons")
def list_comparisons(
    user_id: str = Depends(current_user), session: Session = Depends(get_session)
) -> list[dict]:
    rows = (
        session.query(Comparison)
        .filter(Comparison.user_id == user_id)
        .order_by(Comparison.created_at.desc())
        .all()
    )
    return [
        {
            "id": c.id,
            "analysis_ids": c.analysis_ids,
            "recommended_label": c.result.get("recommended_label"),
            "created_at": c.created_at.isoformat(),
        }
        for c in rows
    ]


# ---------------------------------------------------------------- salary


@router.post("/salary/benchmark")
def salary_benchmark(payload: SalaryRequest) -> dict:
    return SalaryCVAgent().run(
        offered_salary=payload.offered_salary,
        job_title=payload.job_title,
        city=payload.city,
        cv_text=payload.cv_text,
        locale=payload.locale,
    )


# ---------------------------------------------------------------- regulations


@router.get("/regulations")
def regulations() -> dict:
    return regulation_checker.check()


@router.post("/regulations/ask")
def ask_regulations(payload: AskRequest) -> dict:
    return RegulatoryRAGAgent().run(payload.question, locale=payload.locale)


@router.post("/regulations/reindex")
def reindex() -> dict:
    from app.rag.chunking import load_corpus
    from app.rag.vector_store import VectorStore, reset_store

    chunks = load_corpus(settings.regulations_dir)
    store = VectorStore()
    store.build(chunks)
    store.save()
    reset_store()
    return {"indexed_chunks": len(chunks), "embedder": store.embedder.name}


# ---------------------------------------------------------------- chat


@router.post("/chat", response_model=ChatResponse)
def chat(
    payload: ChatRequest,
    user_id: str = Depends(current_user),
    session: Session = Depends(get_session),
) -> ChatResponse:
    result = orchestrator.handle(
        session, user_id, payload.session_id, payload.message, payload.locale
    )
    return ChatResponse(**result)
