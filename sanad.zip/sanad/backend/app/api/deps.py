from fastapi import Header


def current_user(x_user_id: str = Header(default="demo-user")) -> str:
    """Auth stand-in.

    Sanad is meant to be public, so the API is keyed on a user id header. Swap
    this dependency for real token verification without touching the routes.
    """
    return x_user_id
