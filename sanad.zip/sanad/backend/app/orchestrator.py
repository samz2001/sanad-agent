"""Orchestrator / Supervisor agent.

Four jobs, matching the architecture:

1. intent analysis    - what is the user actually asking for
2. task routing       - which agents and tools that needs
3. context management - what the user already has in this session
4. response synthesis - one reply, with the trace of what ran

Routing is rule-first with an LLM classifier layered on when a key is set, so
the system behaves identically offline and stays cheap to run.
"""

from __future__ import annotations

import re
from dataclasses import dataclass, field

from sqlalchemy.orm import Session

from app.agents.regulatory_rag import RegulatoryRAGAgent
from app.agents.salary_cv import SalaryCVAgent
from app.db.models import Analysis, ChatMessage, Document
from app.llm.client import llm
from app.services import analysis_to_dict, compare_analyses, hydrate_facts

INTENTS = (
    "regulatory_question",
    "contract_question",
    "salary_question",
    "compare_offers",
    "help",
)

PATTERNS = {
    "compare_offers": [r"قارن", r"أيهما", r"أفضل عرض", r"المفاضلة", r"compare", r"which offer", r"better offer"],
    "salary_question": [r"راتب", r"الأجر", r"سوق العمل", r"كم يستحق", r"salary", r"pay range", r"market rate", r"underpaid"],
    "contract_question": [r"عقدي", r"هذا العقد", r"البند", r"الشرط", r"my contract", r"this contract", r"clause"],
    "regulatory_question": [r"نظام العمل", r"المادة", r"يحق لي", r"القانون", r"labor law", r"article", r"am i entitled", r"legally"],
}

HELP_AR = (
    "أستطيع مساعدتك في ثلاثة أشياء: تحليل عقد عمل ورفع تقرير بالمخالفات والبنود الناقصة، "
    "ومقارنة عقدك بنطاق الرواتب المرجعي، والمفاضلة بين عرضين أو أكثر حسب أولوياتك. "
    "ارفع العقد للبدء."
)
HELP_EN = (
    "I can do three things: review an employment contract and report violations and missing "
    "clauses, benchmark the pay against a reference range, and compare two or more offers "
    "against your own priorities. Upload a contract to start."
)


@dataclass
class SessionContext:
    user_id: str
    session_id: str
    locale: str = "ar"
    documents: list[Document] = field(default_factory=list)
    analyses: list[Analysis] = field(default_factory=list)
    history: list[ChatMessage] = field(default_factory=list)


class Orchestrator:
    def __init__(self) -> None:
        self.trace: list[dict] = []

    # ---------- 3. context management ----------

    def build_context(self, session: Session, user_id: str, session_id: str, locale: str) -> SessionContext:
        documents = (
            session.query(Document)
            .filter(Document.user_id == user_id)
            .order_by(Document.created_at.desc())
            .limit(10)
            .all()
        )
        analyses = (
            session.query(Analysis)
            .filter(Analysis.user_id == user_id)
            .order_by(Analysis.created_at.desc())
            .limit(10)
            .all()
        )
        history = (
            session.query(ChatMessage)
            .filter(ChatMessage.session_id == session_id)
            .order_by(ChatMessage.created_at.desc())
            .limit(8)
            .all()
        )[::-1]
        return SessionContext(user_id, session_id, locale, documents, analyses, history)

    # ---------- 1. intent analysis ----------

    def classify(self, message: str, context: SessionContext) -> str:
        for intent, patterns in PATTERNS.items():
            if any(re.search(p, message, re.I) for p in patterns):
                self.trace.append({"agent": "orchestrator", "action": "classify", "intent": intent, "mode": "rules"})
                return intent

        if llm.available:
            payload = llm.json(
                "Classify the user's message into exactly one intent. "
                f"Allowed values: {', '.join(INTENTS)}. Return {{\"intent\": \"...\"}}.",
                message,
            )
            intent = (payload or {}).get("intent")
            if intent in INTENTS:
                self.trace.append({"agent": "orchestrator", "action": "classify", "intent": intent, "mode": "llm"})
                return intent

        fallback = "contract_question" if context.analyses else "help"
        self.trace.append({"agent": "orchestrator", "action": "classify", "intent": fallback, "mode": "fallback"})
        return fallback

    # ---------- 2. task routing ----------

    def handle(
        self, session: Session, user_id: str, session_id: str, message: str, locale: str = "ar"
    ) -> dict:
        self.trace = []
        context = self.build_context(session, user_id, session_id, locale)
        intent = self.classify(message, context)

        session.add(ChatMessage(user_id=user_id, session_id=session_id, role="user", content=message))
        session.commit()

        if intent == "regulatory_question":
            result = self._regulatory(message, locale)
        elif intent == "contract_question":
            result = self._contract(session, message, context)
        elif intent == "salary_question":
            result = self._salary(session, message, context)
        elif intent == "compare_offers":
            result = self._compare(session, context)
        else:
            result = {"reply": HELP_AR if locale == "ar" else HELP_EN, "data": {}, "agents": []}

        reply = {
            "intent": intent,
            "reply": result["reply"],
            "data": result.get("data", {}),
            "agents": result.get("agents", []),
            "citations": result.get("citations", []),
            "trace": self.trace + result.get("trace", []),
        }
        session.add(
            ChatMessage(
                user_id=user_id,
                session_id=session_id,
                role="assistant",
                content=reply["reply"],
                trace={"intent": intent, "agents": reply["agents"]},
            )
        )
        session.commit()
        return reply

    # ---------- routes ----------

    def _regulatory(self, message: str, locale: str) -> dict:
        agent = RegulatoryRAGAgent()
        result = agent.run(message, locale=locale)
        return {
            "reply": result["answer"],
            "citations": result["citations"],
            "data": {"regulation_currency": result["regulation_currency"]},
            "agents": ["regulatory_rag"],
            "trace": result["trace"],
        }

    def _contract(self, session: Session, message: str, context: SessionContext) -> dict:
        if not context.analyses:
            reply = (
                "لم أجد عقدًا محللًا في حسابك. ارفع العقد أولًا ثم اسألني عن أي بند فيه."
                if context.locale == "ar"
                else "There is no analysed contract in your account yet. Upload one and then ask about any clause."
            )
            return {"reply": reply, "data": {}, "agents": []}

        analysis = context.analyses[0]
        document = session.get(Document, analysis.document_id)
        rag = RegulatoryRAGAgent()
        grounded = rag.run(message, locale=context.locale)

        summary = analysis.summary_ar if context.locale == "ar" else analysis.summary_en
        reply = f"{summary}\n\n{grounded['answer']}"
        return {
            "reply": reply,
            "citations": grounded["citations"],
            "data": {"analysis": analysis_to_dict(analysis, document)},
            "agents": ["contract_analysis", "regulatory_rag"],
            "trace": grounded["trace"],
        }

    def _salary(self, session: Session, message: str, context: SessionContext) -> dict:
        agent = SalaryCVAgent()
        if context.analyses:
            analysis = context.analyses[0]
            facts = hydrate_facts(session, analysis)
            cv = next((d for d in context.documents if d.kind == "cv"), None)
            result = agent.run(
                offered_salary=facts.get("total_salary") or facts.get("basic_salary"),
                job_title=facts.get("job_title", ""),
                city=facts.get("city", ""),
                cv_text=cv.text if cv else "",
                locale=context.locale,
            )
        else:
            title = re.sub(r".*?(?:راتب|salary|for a|ل)\s*", "", message, flags=re.I)[:60]
            result = agent.run(offered_salary=None, job_title=title, locale=context.locale)

        reply = result["message_ar"] if context.locale == "ar" else result["message_en"]
        source = result["benchmark"].get("source", "none")
        reply += (
            f"\n\nالمصدر: {source}" if context.locale == "ar" else f"\n\nSource: {source}"
        )
        return {"reply": reply, "data": {"salary": result}, "agents": ["salary_cv"], "trace": result["trace"]}

    def _compare(self, session: Session, context: SessionContext) -> dict:
        if len(context.analyses) < 2:
            reply = (
                "المقارنة تحتاج عقدين محللين على الأقل. ارفع العرض الثاني وسأقارنهما."
                if context.locale == "ar"
                else "Comparison needs at least two analysed contracts. Upload the second offer and I will compare them."
            )
            return {"reply": reply, "data": {}, "agents": []}

        ids = [a.id for a in context.analyses[:2]]
        comparison = compare_analyses(session, context.user_id, ids, locale=context.locale)
        result = comparison.result
        reply = result["explanation_ar"] if context.locale == "ar" else result["explanation_en"]
        return {
            "reply": reply,
            "data": {"comparison": result, "comparison_id": comparison.id},
            "agents": ["comparison", "contract_analysis", "salary_cv"],
            "trace": result["trace"],
        }


orchestrator = Orchestrator()
