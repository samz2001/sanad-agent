"""Service layer: the pipelines that both the REST routes and the orchestrator call."""

from __future__ import annotations

from sqlalchemy.orm import Session

from app.agents.comparison import ComparisonAgent
from app.agents.contract_analysis import ContractAnalysisAgent
from app.agents.extraction import extract
from app.agents.salary_cv import SalaryCVAgent
from app.db.models import Analysis, Comparison, Document, User
from app.tools import file_storage


def get_or_create_user(session: Session, user_id: str) -> User:
    user = session.get(User, user_id)
    if user is None:
        user = User(id=user_id)
        session.add(user)
        session.commit()
    return user


def store_document(
    session: Session,
    user_id: str,
    filename: str,
    data: bytes,
    kind: str = "contract",
    mime_type: str = "",
    label: str = "",
    keep_file: bool = True,
) -> Document:
    from app.tools.document_extraction import extract as extract_text

    get_or_create_user(session, user_id)
    document = Document(user_id=user_id, kind=kind, filename=filename, mime_type=mime_type, label=label)
    extracted = extract_text(data, filename, mime_type)
    document.text = extracted.text
    document.extraction_method = extracted.method
    document.language = extracted.language
    if keep_file:
        document.stored_path = file_storage.save(user_id, document.id, filename, data)

    session.add(document)
    session.commit()
    return document


def analyse_document(
    session: Session,
    document: Document,
    cv_text: str = "",
    locale: str = "ar",
) -> Analysis:
    """Runs the contract analysis and salary agents over one stored document."""
    facts = extract(document.text, document.language)

    analysis_agent = ContractAnalysisAgent()
    result = analysis_agent.run(document.text, locale=locale, facts=facts)

    salary_agent = SalaryCVAgent()
    salary = salary_agent.run(
        offered_salary=facts.monthly_total,
        job_title=facts.job_title,
        city=facts.city,
        cv_text=cv_text,
        locale=locale,
    )

    analysis = Analysis(
        document_id=document.id,
        user_id=document.user_id,
        overall_score=result["overall_score"],
        compliance_status=result["compliance_status"],
        scorecard=result["scorecard"],
        findings=result["findings"],
        missing_clauses=result["missing_clauses"],
        citations=result["citations"],
        salary=salary,
        summary_ar=result["summary_ar"],
        summary_en=result["summary_en"],
    )
    session.add(analysis)
    session.commit()
    return analysis


def analysis_to_dict(analysis: Analysis, document: Document | None = None) -> dict:
    facts = {}
    for finding in analysis.findings or []:
        pass
    payload = {
        "id": analysis.id,
        "document_id": analysis.document_id,
        "label": (document.label or document.filename) if document else "",
        "overall_score": analysis.overall_score,
        "compliance_status": analysis.compliance_status,
        "scorecard": analysis.scorecard,
        "findings": analysis.findings,
        "missing_clauses": analysis.missing_clauses,
        "citations": analysis.citations,
        "salary": analysis.salary,
        "summary_ar": analysis.summary_ar,
        "summary_en": analysis.summary_en,
        "created_at": analysis.created_at.isoformat() if analysis.created_at else None,
        "facts": (analysis.salary or {}).get("contract_facts", facts),
    }
    return payload


def hydrate_facts(session: Session, analysis: Analysis) -> dict:
    """Re-derives contract facts from the stored document text."""
    document = session.get(Document, analysis.document_id)
    if document is None:
        return {}
    return extract(document.text, document.language).to_dict()


def compare_analyses(
    session: Session,
    user_id: str,
    analysis_ids: list[str],
    weights: dict | None = None,
    locale: str = "ar",
) -> Comparison:
    payloads = []
    for analysis_id in analysis_ids:
        analysis = session.get(Analysis, analysis_id)
        if analysis is None or analysis.user_id != user_id:
            raise ValueError(f"Unknown analysis: {analysis_id}")
        document = session.get(Document, analysis.document_id)
        payload = analysis_to_dict(analysis, document)
        payload["facts"] = hydrate_facts(session, analysis)
        payloads.append(payload)

    result = ComparisonAgent().run(payloads, weights=weights, locale=locale)
    comparison = Comparison(
        user_id=user_id, analysis_ids=analysis_ids, weights=result["weights"], result=result
    )
    session.add(comparison)
    session.commit()
    return comparison
