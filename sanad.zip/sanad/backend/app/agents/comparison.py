"""Agent 4 - Comparison and Recommendation.

Activates once two or more analysed offers exist. It reuses the scorecards the
analysis agent already produced, adds pay positioning from the salary agent,
applies the user's own priority weights, and returns a ranked result with the
trade-offs spelled out. The weights are the user's, never the model's.
"""

from __future__ import annotations

from app.agents.base import Agent
from app.llm.client import llm

DEFAULT_WEIGHTS = {
    "pay": 0.30,
    "compliance": 0.20,
    "benefits": 0.15,
    "growth": 0.15,
    "flexibility": 0.10,
    "stability": 0.10,
}

FACTOR_LABELS = {
    "pay": ("الأجر", "Pay"),
    "compliance": ("الالتزام النظامي", "Compliance"),
    "benefits": ("المزايا", "Benefits"),
    "growth": ("النمو المهني", "Growth"),
    "flexibility": ("المرونة", "Flexibility"),
    "stability": ("الاستقرار", "Stability"),
}

MEANINGFUL_GAP = 6.0  # score points below which two offers are called close


def _normalise_weights(weights: dict | None) -> dict:
    merged = {**DEFAULT_WEIGHTS, **{k: float(v) for k, v in (weights or {}).items() if k in DEFAULT_WEIGHTS}}
    total = sum(merged.values()) or 1.0
    return {k: v / total for k, v in merged.items()}


def _pay_score(analysis: dict, all_salaries: list[float]) -> float:
    salary = analysis.get("salary") or {}
    placement = (salary.get("placement") or {}).get("verdict", "unknown")
    base = {"above": 85.0, "within": 65.0, "below": 35.0, "unknown": 50.0}[placement]

    offered = salary.get("offered_salary")
    known = [s for s in all_salaries if s]
    if offered and len(known) > 1:
        low, high = min(known), max(known)
        relative = 0.5 if high == low else (offered - low) / (high - low)
        base = 0.6 * base + 0.4 * (40 + relative * 60)
    return round(min(100.0, base), 1)


def _growth_score(facts: dict) -> float:
    score = 45.0
    if facts.get("mentions_training"):
        score += 25
    if facts.get("mentions_bonus"):
        score += 15
    if facts.get("contract_type") == "open":
        score += 10
    return round(min(100.0, score), 1)


def _flexibility_score(facts: dict, scorecard: dict) -> float:
    score = float(scorecard.get("time_and_leave", {}).get("score", 50))
    if facts.get("mentions_remote_work"):
        score = min(100.0, score + 20)
    weekly = facts.get("weekly_hours")
    if weekly and weekly <= 40:
        score = min(100.0, score + 10)
    return round(score, 1)


def _stability_score(facts: dict, scorecard: dict) -> float:
    score = float(scorecard.get("termination", {}).get("score", 50))
    if facts.get("contract_type") == "open":
        score = min(100.0, score + 10)
    if facts.get("contract_type") == "flexible":
        score = max(0.0, score - 20)
    probation = facts.get("probation_days")
    if probation and probation > 90:
        score = max(0.0, score - 10)
    return round(score, 1)


class ComparisonAgent(Agent):
    name = "comparison"
    description = "Ranks two or more analysed offers against the user's priorities."

    def factors(self, analysis: dict, all_salaries: list[float]) -> dict:
        facts = analysis.get("facts", {})
        scorecard = analysis.get("scorecard", {})
        return {
            "pay": _pay_score(analysis, all_salaries),
            "compliance": float(scorecard.get("compliance", {}).get("score", 50)),
            "benefits": float(scorecard.get("benefits", {}).get("score", 50)),
            "growth": _growth_score(facts),
            "flexibility": _flexibility_score(facts, scorecard),
            "stability": _stability_score(facts, scorecard),
        }

    def _tradeoffs(self, offers: list[dict], locale: str) -> list[dict]:
        if len(offers) < 2:
            return []
        best, runner = offers[0], offers[1]
        out = []
        for factor in DEFAULT_WEIGHTS:
            delta = runner["factors"][factor] - best["factors"][factor]
            if delta > MEANINGFUL_GAP:
                ar, en = FACTOR_LABELS[factor]
                out.append(
                    {
                        "factor": factor,
                        "winner": runner["label"],
                        "delta": round(delta, 1),
                        "text_ar": f"{runner['label']} أفضل في {ar} بفارق {delta:.0f} نقطة.",
                        "text_en": f"{runner['label']} is stronger on {en} by {delta:.0f} points.",
                    }
                )
        return out

    def run(self, analyses: list[dict], weights: dict | None = None, locale: str = "ar") -> dict:
        if len(analyses) < 2:
            raise ValueError("Comparison needs at least two analysed contracts")

        weights = _normalise_weights(weights)
        all_salaries = [
            (a.get("salary") or {}).get("offered_salary") for a in analyses
        ]
        all_salaries = [s for s in all_salaries if s]

        offers = []
        for index, analysis in enumerate(analyses):
            factors = self.factors(analysis, all_salaries)
            weighted = sum(factors[f] * weights[f] for f in weights)
            offers.append(
                {
                    "analysis_id": analysis.get("id", f"offer-{index + 1}"),
                    "label": analysis.get("label") or f"عرض {index + 1}",
                    "employer": analysis.get("facts", {}).get("employer", ""),
                    "job_title": analysis.get("facts", {}).get("job_title", ""),
                    "offered_salary": (analysis.get("salary") or {}).get("offered_salary"),
                    "compliance_status": analysis.get("compliance_status", "unknown"),
                    "factors": factors,
                    "weighted_score": round(weighted, 1),
                    "blocking_violations": [
                        f["title_ar"] if locale == "ar" else f["title_en"]
                        for f in analysis.get("findings", [])
                        if f["status"] == "violation" and f["severity"] == "critical"
                    ],
                }
            )

        offers.sort(key=lambda o: -o["weighted_score"])
        gap = offers[0]["weighted_score"] - offers[1]["weighted_score"]
        close_call = gap < MEANINGFUL_GAP
        tradeoffs = self._tradeoffs(offers, locale)
        self.log("rank", winner=offers[0]["label"], gap=round(gap, 1))

        winner = offers[0]
        top_factor = max(weights, key=lambda f: weights[f] * winner["factors"][f])
        factor_ar, factor_en = FACTOR_LABELS[top_factor]

        reason_ar = (
            f"{winner['label']} يتقدم بفارق {gap:.0f} نقطة، وأقوى ما يميزه حسب أولوياتك هو {factor_ar}."
        )
        reason_en = (
            f"{winner['label']} leads by {gap:.0f} points, strongest on {factor_en} given your priorities."
        )
        if close_call:
            reason_ar += " الفارق ضيق، والقرار هنا يعود لتفضيلك الشخصي أكثر من الأرقام."
            reason_en += " The gap is narrow, so this comes down to preference more than numbers."
        if winner["blocking_violations"]:
            reason_ar += " لكن هذا العرض يحتوي مخالفات جوهرية يجب تعديلها قبل التوقيع."
            reason_en += " It does contain critical violations that should be fixed before signing."

        if llm.available:
            summary = llm.text(
                "You explain to a job seeker which of their offers scores higher and why. "
                "Four sentences maximum. Use only the supplied numbers. Name the trade-offs. "
                "Arabic first, then a line '---', then English.",
                str(
                    {
                        "weights": weights,
                        "offers": [
                            {k: o[k] for k in ("label", "factors", "weighted_score", "offered_salary")}
                            for o in offers
                        ],
                    }
                ),
            )
            if summary and "---" in summary:
                part_ar, _, part_en = summary.partition("---")
                reason_ar, reason_en = part_ar.strip() or reason_ar, part_en.strip() or reason_en

        return {
            "weights": weights,
            "offers": offers,
            "recommended": winner["analysis_id"],
            "recommended_label": winner["label"],
            "close_call": close_call,
            "score_gap": round(gap, 1),
            "tradeoffs": tradeoffs,
            "explanation_ar": reason_ar,
            "explanation_en": reason_en,
            "trace": self.trace,
        }
