"""Turns raw contract text into a structured `ContractFacts` record.

Two paths, same output shape:

* deterministic regex extraction over Arabic and English contract wording, and
* an LLM pass that fills gaps when a provider key is configured.

The regex pass always runs first so there is a usable result even offline, and
so the LLM output can be sanity-checked against it.
"""

from __future__ import annotations

import re
from dataclasses import asdict, dataclass, field

from app.llm.client import llm

ARABIC_DIGITS = str.maketrans("٠١٢٣٤٥٦٧٨٩", "0123456789")


@dataclass
class ContractFacts:
    job_title: str = ""
    employer: str = ""
    city: str = ""
    contract_type: str = "unknown"  # fixed | open | flexible | unknown
    duration_months: int | None = None
    basic_salary: float | None = None
    housing_allowance: float | None = None
    transport_allowance: float | None = None
    other_allowances: float | None = None
    total_salary: float | None = None
    currency: str = "SAR"
    pay_period: str = "month"
    probation_days: int | None = None
    notice_days: int | None = None
    annual_leave_days: int | None = None
    daily_hours: float | None = None
    weekly_hours: float | None = None
    non_compete_months: int | None = None
    mentions_overtime: bool = False
    mentions_end_of_service: bool = False
    mentions_medical_insurance: bool = False
    mentions_social_insurance: bool = False
    mentions_dispute_resolution: bool = False
    mentions_job_description: bool = False
    mentions_start_date: bool = False
    mentions_wage_protection: bool = False
    mentions_training: bool = False
    mentions_remote_work: bool = False
    mentions_bonus: bool = False
    worker_pays_recruitment_fees: bool = False
    language: str = "ar"
    extraction_source: str = "rules"
    raw_matches: dict = field(default_factory=dict)

    def to_dict(self) -> dict:
        return asdict(self)

    @property
    def monthly_total(self) -> float | None:
        if self.total_salary is not None:
            return self.total_salary
        parts = [
            self.basic_salary,
            self.housing_allowance,
            self.transport_allowance,
            self.other_allowances,
        ]
        known = [p for p in parts if p is not None]
        return sum(known) if known else None


def _normalise(text: str) -> str:
    text = text.translate(ARABIC_DIGITS)
    text = text.replace("٫", ".").replace("،", ",")
    return re.sub(r"[ \t]+", " ", text)


def _number(value: str) -> float | None:
    try:
        return float(value.replace(",", "").strip())
    except (ValueError, AttributeError):
        return None


def _find_amount(text: str, keywords: list[str]) -> float | None:
    for keyword in keywords:
        pattern = rf"{keyword}[^\n\d]{{0,60}}?([\d][\d,]*(?:\.\d+)?)"
        match = re.search(pattern, text, re.I)
        if match:
            value = _number(match.group(1))
            if value and value > 100:  # filter out article numbers and percentages
                return value
    return None


def _find_days(text: str, keywords: list[str]) -> int | None:
    for keyword in keywords:
        pattern = rf"{keyword}[^\n\d]{{0,60}}?(\d{{1,3}})\s*(يوم|أيام|يوما|يومًا|day|days|شهر|أشهر|شهرا|شهرًا|month|months)"
        match = re.search(pattern, text, re.I)
        if match:
            amount = int(match.group(1))
            unit = match.group(2).lower()
            if unit.startswith(("شهر", "أشهر", "month")):
                amount *= 30
            return amount
    return None


def _has(text: str, keywords: list[str]) -> bool:
    return any(re.search(k, text, re.I) for k in keywords)


def extract_rules(text: str, language: str = "ar") -> ContractFacts:
    t = _normalise(text)
    facts = ContractFacts(language=language)

    title = re.search(r"(?:المسمى الوظيفي|الوظيفة|المهنة|job title|position)\s*[:：\-]?\s*(.{3,60})", t, re.I)
    if title:
        facts.job_title = title.group(1).split("\n")[0].strip(" .:-|")

    employer = re.search(r"(?:صاحب العمل|الطرف الأول|employer|company)\s*[:：\-]?\s*(.{3,80})", t, re.I)
    if employer:
        facts.employer = employer.group(1).split("\n")[0].strip(" .:-|")

    for city_ar, city_en in [
        ("الرياض", "Riyadh"),
        ("جدة", "Jeddah"),
        ("الدمام", "Dammam"),
        ("الخبر", "Khobar"),
        ("مكة", "Makkah"),
        ("المدينة", "Madinah"),
        ("نيوم", "NEOM"),
    ]:
        if city_ar in t or re.search(city_en, t, re.I):
            facts.city = city_en
            break

    if _has(t, [r"غير محدد المدة", r"open[- ]ended", r"indefinite"]):
        facts.contract_type = "open"
    elif _has(t, [r"محدد المدة", r"fixed[- ]term"]):
        facts.contract_type = "fixed"
    if _has(t, [r"العمل المرن", r"بالساعة", r"flexible work", r"hourly"]):
        facts.contract_type = "flexible"

    duration = re.search(r"مدة (?:العقد|هذا العقد)[^\n\d]{0,40}?(\d{1,2})\s*(سنة|سنوات|شهر|أشهر|year|month)", t, re.I)
    if duration:
        value = int(duration.group(1))
        facts.duration_months = value * 12 if duration.group(2).startswith(("سنة", "سنوات", "year")) else value

    facts.basic_salary = _find_amount(t, [r"الأجر الأساسي", r"الراتب الأساسي", r"basic (?:salary|wage)"])
    facts.housing_allowance = _find_amount(t, [r"بدل السكن", r"بدل سكن", r"housing allowance"])
    facts.transport_allowance = _find_amount(t, [r"بدل النقل", r"بدل نقل", r"بدل المواصلات", r"transport(?:ation)? allowance"])
    facts.other_allowances = _find_amount(t, [r"بدلات أخرى", r"other allowances"])
    facts.total_salary = _find_amount(t, [r"إجمالي الراتب", r"الأجر الإجمالي", r"الراتب الشهري الإجمالي", r"total (?:salary|package)", r"gross salary"])
    if facts.basic_salary is None and facts.total_salary is None:
        facts.basic_salary = _find_amount(t, [r"الراتب", r"الأجر", r"salary", r"wage"])

    if re.search(r"(دولار|USD|\$)", t):
        facts.currency = "USD"
    elif re.search(r"(يورو|EUR|€)", t):
        facts.currency = "EUR"

    facts.probation_days = _find_days(t, [r"فترة التجربة", r"مدة التجربة", r"probation"])
    facts.notice_days = _find_days(t, [r"إشعار", r"إخطار", r"notice period", r"notice"])
    facts.annual_leave_days = _find_days(t, [r"الإجازة السنوية", r"إجازة سنوية", r"annual leave"])
    facts.non_compete_months = None
    non_compete = _find_days(t, [r"عدم المنافسة", r"non[- ]compete"])
    if non_compete:
        facts.non_compete_months = max(1, round(non_compete / 30))

    daily = re.search(r"(\d{1,2})\s*(?:ساعة|ساعات)\s*(?:عمل\s*)?(?:يوميا|يوميًا|في اليوم)", t)
    if daily:
        facts.daily_hours = float(daily.group(1))
    daily_en = re.search(r"(\d{1,2})\s*hours?\s*(?:per|a)\s*day", t, re.I)
    if daily_en and facts.daily_hours is None:
        facts.daily_hours = float(daily_en.group(1))

    weekly = re.search(r"(\d{1,3})\s*(?:ساعة|ساعات)\s*(?:عمل\s*)?(?:أسبوعيا|أسبوعيًا|في الأسبوع)", t)
    if weekly:
        facts.weekly_hours = float(weekly.group(1))
    weekly_en = re.search(r"(\d{1,2})\s*hours?\s*(?:per|a)\s*week", t, re.I)
    if weekly_en and facts.weekly_hours is None:
        facts.weekly_hours = float(weekly_en.group(1))
    if facts.weekly_hours is None and facts.daily_hours is not None:
        days = 6 if re.search(r"ستة أيام|six days", t, re.I) else 5
        facts.weekly_hours = facts.daily_hours * days

    facts.mentions_overtime = _has(t, [r"العمل الإضافي", r"ساعات إضافية", r"overtime"])
    facts.mentions_end_of_service = _has(t, [r"مكافأة نهاية الخدمة", r"end[- ]of[- ]service"])
    facts.mentions_medical_insurance = _has(t, [r"التأمين الطبي", r"التأمين الصحي", r"medical insurance", r"health insurance"])
    facts.mentions_social_insurance = _has(t, [r"التأمينات الاجتماعية", r"GOSI", r"social insurance"])
    facts.mentions_dispute_resolution = _has(t, [r"المحاكم العمالية", r"تسوية المنازعات", r"dispute", r"labor court"])
    facts.mentions_job_description = _has(t, [r"وصف العمل", r"المهام", r"job description", r"duties"])
    facts.mentions_start_date = _has(t, [r"تاريخ المباشرة", r"تاريخ الالتحاق", r"start date", r"commencement"])
    facts.mentions_wage_protection = _has(t, [r"حماية الأجور", r"wage protection"])
    facts.mentions_training = _has(t, [r"تدريب", r"تطوير مهني", r"شهادات", r"training", r"professional development", r"certification"])
    facts.mentions_remote_work = _has(t, [r"عن بعد", r"العمل المرن", r"هجين", r"remote", r"hybrid", r"work from home"])
    facts.mentions_bonus = _has(t, [r"مكافأة سنوية", r"حوافز", r"عمولة", r"bonus", r"incentive", r"commission"])
    facts.worker_pays_recruitment_fees = _has(
        t, [r"يتحمل العامل[^\n]{0,60}(الاستقدام|الإقامة|رخصة العمل|التأشيرة)", r"worker (?:shall )?bear[^\n]{0,40}(recruitment|iqama|visa)"]
    )
    return facts


LLM_SYSTEM = (
    "You extract structured facts from Saudi employment contracts written in Arabic or English. "
    "Only report values that literally appear in the contract. Use null for anything absent. "
    "Never infer a salary that is not written."
)

LLM_KEYS = {
    "job_title": str,
    "employer": str,
    "city": str,
    "contract_type": str,
    "duration_months": int,
    "basic_salary": float,
    "housing_allowance": float,
    "transport_allowance": float,
    "total_salary": float,
    "currency": str,
    "probation_days": int,
    "notice_days": int,
    "annual_leave_days": int,
    "daily_hours": float,
    "weekly_hours": float,
    "non_compete_months": int,
}


def extract(text: str, language: str = "ar") -> ContractFacts:
    facts = extract_rules(text, language)
    if not llm.available:
        return facts

    payload = llm.json(
        LLM_SYSTEM,
        "Extract these fields as JSON: "
        + ", ".join(LLM_KEYS)
        + ".\n\nCONTRACT:\n"
        + text[:12000],
    )
    if not payload:
        return facts

    facts.extraction_source = "rules+llm"
    for key, caster in LLM_KEYS.items():
        value = payload.get(key)
        if value in (None, "", "null"):
            continue
        try:
            typed = caster(value)
        except (TypeError, ValueError):
            continue
        if getattr(facts, key, None) in (None, "", "unknown"):
            setattr(facts, key, typed)
        facts.raw_matches[key] = value
    return facts
