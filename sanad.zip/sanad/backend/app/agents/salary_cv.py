"""Agent 3 - Salary and CV.

Reads the CV when one is supplied, works out job family, seniority and city,
then looks up a benchmark range. It always returns a range plus the source it
came from, never a single confident number, and says whether the offer sits
above, within or below that range.

Source order: local benchmark table (GASTAT extract) -> job-family fallback ->
`none`. The web fallback in the architecture plugs into `_web_lookup`.
"""

from __future__ import annotations

import csv
import re
from dataclasses import dataclass, field
from pathlib import Path

from app.agents.base import Agent
from app.config import settings
from app.llm.client import llm

SENIORITY_ORDER = ["entry", "mid", "senior"]

TITLE_HINTS = {
    "senior": [r"\bsenior\b", r"\blead\b", r"\bprincipal\b", r"\bmanager\b", r"كبير", r"أول", r"رئيس"],
    "entry": [r"\bjunior\b", r"\bintern\b", r"\bgraduate\b", r"\btrainee\b", r"مبتدئ", r"متدرب", r"حديث التخرج"],
}


@dataclass
class CVProfile:
    job_title: str = ""
    years_experience: float | None = None
    seniority: str = ""
    city: str = ""
    skills: list[str] = field(default_factory=list)
    source: str = "none"


def _load_benchmarks() -> list[dict]:
    path = Path(settings.salary_data_path)
    if not path.exists():
        return []
    rows = []
    with path.open(encoding="utf-8") as fh:
        lines = [line for line in fh if not line.startswith("#")]
    for row in csv.DictReader(lines):
        for key in ("p25", "p50", "p75"):
            row[key] = float(row[key])
        rows.append(row)
    return rows


def _tokens(value: str) -> set[str]:
    return {t for t in re.split(r"[^\w\u0600-\u06FF]+", (value or "").lower()) if len(t) > 2}


def _similarity(a: str, b: str) -> float:
    ta, tb = _tokens(a), _tokens(b)
    if not ta or not tb:
        return 0.0
    return len(ta & tb) / len(ta | tb)


def infer_seniority(title: str, years: float | None) -> str:
    for level, patterns in TITLE_HINTS.items():
        if any(re.search(p, title or "", re.I) for p in patterns):
            return level
    if years is None:
        return "mid"
    if years < 2:
        return "entry"
    if years < 7:
        return "mid"
    return "senior"


class SalaryCVAgent(Agent):
    name = "salary_cv"
    description = "Reads the CV, picks a benchmark range, and positions the offer against it."

    def __init__(self) -> None:
        super().__init__()
        self.benchmarks = _load_benchmarks()

    # ---------- CV ----------

    def parse_cv(self, text: str) -> CVProfile:
        profile = CVProfile(source="rules")
        years = re.search(r"(\d{1,2})\+?\s*(?:years?|سنة|سنوات)\s*(?:of\s*)?(?:experience|خبرة)", text, re.I)
        if years:
            profile.years_experience = float(years.group(1))

        title = re.search(r"(?:current(?:ly)?|title|المسمى|الوظيفة)\s*[:\-]?\s*(.{3,60})", text, re.I)
        if title:
            profile.job_title = title.group(1).split("\n")[0].strip(" .:-|")
        if not profile.job_title:
            for line in text.splitlines()[:12]:
                if 6 < len(line.strip()) < 60 and _tokens(line) & {
                    "engineer", "analyst", "developer", "specialist", "manager", "consultant",
                    "مهندس", "محلل", "مطور", "أخصائي", "مدير",
                }:
                    profile.job_title = line.strip()
                    break

        for city in ["Riyadh", "Jeddah", "Dammam", "Khobar", "الرياض", "جدة", "الدمام"]:
            if re.search(city, text, re.I):
                profile.city = {"الرياض": "Riyadh", "جدة": "Jeddah", "الدمام": "Dammam"}.get(city, city)
                break

        skills = re.search(r"(?:skills|المهارات)\s*[:\-]?\s*(.{10,400})", text, re.I | re.S)
        if skills:
            profile.skills = [
                s.strip() for s in re.split(r"[,،|\n•]", skills.group(1)) if 1 < len(s.strip()) < 40
            ][:20]

        if llm.available:
            payload = llm.json(
                "Extract CV facts as JSON. Keys: job_title, years_experience (number), city, "
                "skills (array of strings). Use null when absent.",
                text[:8000],
            )
            if payload:
                profile.source = "rules+llm"
                profile.job_title = profile.job_title or (payload.get("job_title") or "")
                profile.city = profile.city or (payload.get("city") or "")
                if profile.years_experience is None and isinstance(payload.get("years_experience"), (int, float)):
                    profile.years_experience = float(payload["years_experience"])
                if not profile.skills and isinstance(payload.get("skills"), list):
                    profile.skills = [str(s) for s in payload["skills"]][:20]

        profile.seniority = infer_seniority(profile.job_title, profile.years_experience)
        self.log("parse_cv", title=profile.job_title, seniority=profile.seniority)
        return profile

    # ---------- benchmark lookup ----------

    def _web_lookup(self, title: str, city: str, seniority: str) -> dict | None:
        """Hook for the trusted-online-sources fallback in the architecture.

        Left unimplemented on purpose: wiring a scraper in here without a
        source whitelist would put unverifiable numbers in front of users.
        """
        self.log("web_lookup", status="not_configured")
        return None

    def lookup(self, title: str, city: str = "", seniority: str = "mid") -> dict:
        if not self.benchmarks:
            return {"found": False, "source": "none"}

        scored = []
        for row in self.benchmarks:
            score = max(_similarity(title, row["title_en"]), _similarity(title, row["title_ar"]))
            if city and row["city"].lower() == city.lower():
                score += 0.25
            if row["seniority"] == seniority:
                score += 0.25
            scored.append((score, row))
        scored.sort(key=lambda pair: -pair[0])
        best_score, best = scored[0]

        if best_score < 0.3:
            web = self._web_lookup(title, city, seniority)
            if web:
                return web
            family_rows = [r for r in self.benchmarks if r["seniority"] == seniority]
            if not family_rows:
                return {"found": False, "source": "none"}
            p25 = min(r["p25"] for r in family_rows)
            p75 = max(r["p75"] for r in family_rows)
            p50 = sorted(r["p50"] for r in family_rows)[len(family_rows) // 2]
            return {
                "found": True,
                "confidence": "low",
                "match": "job family fallback",
                "p25": p25,
                "p50": p50,
                "p75": p75,
                "currency": "SAR",
                "period": "month",
                "city": city or "Saudi Arabia",
                "seniority": seniority,
                "source": "placeholder benchmark table (broad range)",
            }

        return {
            "found": True,
            "confidence": "high" if best_score > 0.7 else "medium",
            "match": f"{best['title_en']} / {best['title_ar']}",
            "p25": best["p25"],
            "p50": best["p50"],
            "p75": best["p75"],
            "currency": best["currency"],
            "period": best["period"],
            "city": best["city"],
            "seniority": best["seniority"],
            "source": f"{best['source']} ({best['year']})",
        }

    # ---------- positioning ----------

    def position(self, offered: float | None, benchmark: dict) -> dict:
        if offered is None or not benchmark.get("found"):
            return {"verdict": "unknown", "gap_to_median": None}
        p25, p50, p75 = benchmark["p25"], benchmark["p50"], benchmark["p75"]
        if offered < p25:
            verdict = "below"
        elif offered > p75:
            verdict = "above"
        else:
            verdict = "within"
        return {
            "verdict": verdict,
            "gap_to_median": round(offered - p50, 2),
            "gap_to_median_pct": round((offered - p50) / p50 * 100, 1) if p50 else None,
        }

    def run(
        self,
        offered_salary: float | None,
        job_title: str = "",
        city: str = "",
        cv_text: str = "",
        locale: str = "ar",
    ) -> dict:
        profile = self.parse_cv(cv_text) if cv_text else CVProfile()
        title = job_title or profile.job_title
        city = city or profile.city
        seniority = profile.seniority or infer_seniority(title, profile.years_experience)

        benchmark = self.lookup(title, city, seniority)
        placement = self.position(offered_salary, benchmark)
        self.log("benchmark", title=title, verdict=placement["verdict"], source=benchmark.get("source"))

        if benchmark.get("found"):
            range_ar = (
                f"النطاق التقديري لهذه الوظيفة: {benchmark['p25']:.0f} - {benchmark['p75']:.0f} "
                f"{benchmark['currency']} شهريًا (الوسيط {benchmark['p50']:.0f})."
            )
            range_en = (
                f"Estimated range: {benchmark['p25']:.0f} - {benchmark['p75']:.0f} "
                f"{benchmark['currency']} per month (median {benchmark['p50']:.0f})."
            )
        else:
            range_ar = "لا يتوفر نطاق مرجعي لهذه الوظيفة في البيانات الحالية."
            range_en = "No reference range is available for this role in the current data."

        verdict_text = {
            "below": ("العرض أقل من النطاق المرجعي.", "The offer is below the reference range."),
            "within": ("العرض ضمن النطاق المرجعي.", "The offer sits within the reference range."),
            "above": ("العرض أعلى من النطاق المرجعي.", "The offer is above the reference range."),
            "unknown": ("تعذر تحديد موقع العرض من النطاق.", "The offer could not be positioned."),
        }[placement["verdict"]]

        return {
            "cv_profile": profile.__dict__,
            "resolved": {"job_title": title, "city": city, "seniority": seniority},
            "benchmark": benchmark,
            "placement": placement,
            "offered_salary": offered_salary,
            "message_ar": f"{range_ar} {verdict_text[0]}",
            "message_en": f"{range_en} {verdict_text[1]}",
            "trace": self.trace,
        }
