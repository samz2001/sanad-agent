"""Agent 1 - Regulatory RAG.

Retrieves the articles that actually govern a question, cites them by document
and article number, and reports how current the cited corpus is. Every other
agent asks this one for its legal ground truth instead of relying on the
model's own recall.
"""

from __future__ import annotations

from app.agents.base import Agent
from app.llm.client import llm
from app.rag.vector_store import get_store
from app.tools import citation_formatter, regulation_checker

SYSTEM_AR = (
    "أنت مساعد قانوني متخصص في نظام العمل السعودي. أجب فقط اعتمادًا على المواد "
    "المرفقة. إذا لم تكفِ المواد للإجابة فقل ذلك صراحة. اذكر رقم المادة بين قوسين "
    "بعد كل حكم. لا تقدم استشارة قانونية ملزمة."
)
SYSTEM_EN = (
    "You are a legal assistant for Saudi labor law. Answer only from the supplied "
    "articles. If they are not sufficient, say so plainly. Put the article number in "
    "brackets after each statement. Do not present this as binding legal advice."
)


class RegulatoryRAGAgent(Agent):
    name = "regulatory_rag"
    description = "Retrieves and cites the governing articles from the MHRSD corpus."

    def retrieve(self, queries: list[str], k: int = 6) -> list[dict]:
        store = get_store()
        if not store.ready:
            self.log("retrieve", status="index_empty", queries=queries)
            return []
        hits = store.multi_search(queries, k_each=max(3, k // 2), k_total=k)
        self.log("retrieve", queries=queries, hits=len(hits), embedder=store.embedder.name)
        return hits

    def _context_block(self, hits: list[dict]) -> str:
        blocks = []
        for hit in hits:
            meta = hit["metadata"]
            header = f"[{meta.get('title_ar')} - المادة {meta.get('article')}]"
            blocks.append(f"{header}\n{hit['text']}")
        return "\n\n".join(blocks)

    def _offline_answer(self, hits: list[dict], locale: str) -> str:
        if not hits:
            return (
                "لم أجد مادة مطابقة في قاعدة الأنظمة الحالية."
                if locale == "ar"
                else "No matching article was found in the current regulatory index."
            )
        lead = (
            "المواد ذات الصلة في قاعدة الأنظمة:"
            if locale == "ar"
            else "Relevant articles in the regulatory index:"
        )
        lines = [lead]
        for hit in hits[:4]:
            meta = hit["metadata"]
            label = citation_formatter.format_citation(hit, locale)["label"]
            body = hit["text"].split("\n", 1)[-1].strip()
            lines.append(f"\n• {label}\n  {body[:320]}")
        return "\n".join(lines)

    def run(self, question: str, locale: str = "ar", k: int = 6) -> dict:
        hits = self.retrieve([question], k=k)
        citations = citation_formatter.format_all(hits, locale)
        doc_ids = list({c["doc_id"] for c in citations})
        currency = regulation_checker.check(doc_ids or None)

        answer = None
        if llm.available and hits:
            answer = llm.text(
                SYSTEM_AR if locale == "ar" else SYSTEM_EN,
                f"{question}\n\n---\n{self._context_block(hits)}",
            )
            self.log("synthesise", mode="llm")
        if not answer:
            answer = self._offline_answer(hits, locale)
            self.log("synthesise", mode="offline")

        return {
            "answer": answer,
            "citations": citations,
            "retrieved": hits,
            "regulation_currency": currency,
            "trace": self.trace,
        }
