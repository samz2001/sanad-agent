"""Agent 2 - Contract Analysis.

Runs a fixed rule set over the extracted contract facts, grounds each finding in
a retrieved article, and produces a fixed-dimension scorecard. The dimensions
never vary between contracts, which is what makes two offers comparable later.

A finding has one of four statuses:
    violation - the clause contradicts a statutory minimum
    risk      - the clause is lawful but works against the worker
    missing   - a required or expected clause is absent
    ok        - the clause is present and at or above the minimum
"""

from __future__ import annotations

import re
from collections.abc import Callable
from dataclasses import dataclass

from app.agents.base import Agent
from app.agents.extraction import ContractFacts, extract
from app.agents.regulatory_rag import RegulatoryRAGAgent
from app.llm.client import llm

DIMENSIONS = {
    "compliance": 0.30,
    "pay": 0.20,
    "time_and_leave": 0.15,
    "termination": 0.15,
    "benefits": 0.12,
    "clarity": 0.08,
}

DIMENSION_LABELS = {
    "compliance": ("الالتزام النظامي", "Regulatory compliance"),
    "pay": ("الأجر والبدلات", "Pay and allowances"),
    "time_and_leave": ("ساعات العمل والإجازات", "Hours and leave"),
    "termination": ("الإنهاء والإشعار", "Termination and notice"),
    "benefits": ("المزايا والتأمين", "Benefits and insurance"),
    "clarity": ("وضوح العقد", "Contract clarity"),
}

PENALTY = {"critical": 45, "high": 25, "medium": 12, "low": 5}

Finding = dict
CheckFn = Callable[[ContractFacts, str], tuple[str, str, str, str] | None]


@dataclass
class Rule:
    id: str
    dimension: str
    query: str
    check: CheckFn
    title_ar: str
    title_en: str


def _r(status: str, severity: str, ar: str, en: str):
    return status, severity, ar, en


# --------------------------------------------------------------------------
# Rule checks. Each returns (status, severity, detail_ar, detail_en) or None.
# --------------------------------------------------------------------------


def check_probation(f: ContractFacts, text: str):
    if f.probation_days is None:
        return _r("ok", "low", "لا توجد فترة تجربة منصوص عليها.", "No probation period is stated.")
    if f.probation_days > 180:
        return _r(
            "violation",
            "high",
            f"فترة التجربة {f.probation_days} يومًا وتتجاوز الحد الأقصى (180 يومًا حتى مع التمديد الكتابي).",
            f"Probation of {f.probation_days} days exceeds the 180-day ceiling even with a written extension.",
        )
    if f.probation_days > 90:
        return _r(
            "risk",
            "medium",
            f"فترة التجربة {f.probation_days} يومًا، وهي تتجاوز 90 يومًا ولا تصح إلا باتفاق كتابي صريح على التمديد.",
            f"Probation of {f.probation_days} days exceeds 90 days and is valid only with an express written extension.",
        )
    return _r("ok", "low", f"فترة التجربة {f.probation_days} يومًا ضمن الحد النظامي.", f"Probation of {f.probation_days} days is within the limit.")


def check_notice(f: ContractFacts, text: str):
    if f.notice_days is None:
        return _r(
            "missing",
            "medium",
            "العقد لا يحدد مدة الإشعار قبل الإنهاء.",
            "The contract does not state a notice period before termination.",
        )
    minimum = 60 if f.contract_type != "flexible" and f.pay_period == "month" else 30
    if f.notice_days < minimum:
        return _r(
            "violation",
            "high",
            f"مدة الإشعار {f.notice_days} يومًا وهي أقل من {minimum} يومًا للأجر الشهري.",
            f"Notice of {f.notice_days} days is below the {minimum}-day minimum for monthly-paid work.",
        )
    return _r("ok", "low", f"مدة الإشعار {f.notice_days} يومًا.", f"Notice period is {f.notice_days} days.")


def check_annual_leave(f: ContractFacts, text: str):
    if f.annual_leave_days is None:
        return _r(
            "missing",
            "medium",
            "العقد لا يذكر عدد أيام الإجازة السنوية.",
            "The contract does not state the number of annual leave days.",
        )
    if f.annual_leave_days < 21:
        return _r(
            "violation",
            "high",
            f"الإجازة السنوية {f.annual_leave_days} يومًا وهي أقل من الحد الأدنى 21 يومًا.",
            f"Annual leave of {f.annual_leave_days} days is below the 21-day statutory minimum.",
        )
    if f.annual_leave_days >= 30:
        return _r("ok", "low", f"الإجازة السنوية {f.annual_leave_days} يومًا، أعلى من الحد الأدنى.", f"Annual leave of {f.annual_leave_days} days is above the minimum.")
    return _r("ok", "low", f"الإجازة السنوية {f.annual_leave_days} يومًا.", f"Annual leave is {f.annual_leave_days} days.")


def check_hours(f: ContractFacts, text: str):
    if f.daily_hours is None and f.weekly_hours is None:
        return _r("missing", "medium", "ساعات العمل غير محددة في العقد.", "Working hours are not specified.")
    if (f.daily_hours or 0) > 8 or (f.weekly_hours or 0) > 48:
        return _r(
            "violation",
            "high",
            f"ساعات العمل ({f.daily_hours or '-'} يوميًا / {f.weekly_hours or '-'} أسبوعيًا) تتجاوز الحد النظامي.",
            f"Working hours ({f.daily_hours or '-'}/day, {f.weekly_hours or '-'}/week) exceed the statutory cap.",
        )
    return _r("ok", "low", "ساعات العمل ضمن الحد النظامي.", "Working hours are within the statutory cap.")


def check_overtime(f: ContractFacts, text: str):
    if not f.mentions_overtime:
        return _r(
            "missing",
            "low",
            "لا يوجد نص على أجر العمل الإضافي.",
            "No clause covers overtime pay.",
        )
    if re.search(r"(دون|بدون|لا)\s*(أجر|مقابل)\s*إضاف|without (?:additional|extra) pay", text, re.I):
        return _r(
            "violation",
            "high",
            "العقد يشير إلى عمل إضافي دون أجر إضافي.",
            "The contract implies overtime without additional pay.",
        )
    return _r("ok", "low", "العقد ينص على أجر العمل الإضافي.", "Overtime pay is addressed.")


def check_end_of_service(f: ContractFacts, text: str):
    if re.search(r"يتنازل[^\n]{0,40}مكافأة نهاية الخدمة|waive[^\n]{0,40}end[- ]of[- ]service", text, re.I):
        return _r(
            "violation",
            "critical",
            "العقد يتضمن تنازلًا عن مكافأة نهاية الخدمة، وهو شرط باطل.",
            "The contract waives the end-of-service award, which is a void term.",
        )
    if not f.mentions_end_of_service:
        return _r(
            "missing",
            "medium",
            "لا يوجد نص على مكافأة نهاية الخدمة. الحق قائم نظامًا حتى لو لم يُذكر.",
            "No end-of-service clause. The entitlement still applies by law.",
        )
    return _r("ok", "low", "مكافأة نهاية الخدمة مذكورة.", "End-of-service award is addressed.")


def check_salary_stated(f: ContractFacts, text: str):
    if f.monthly_total is None:
        return _r(
            "missing",
            "critical",
            "الأجر غير محدد برقم واضح في العقد.",
            "The contract does not state the wage as a clear figure.",
        )
    if f.basic_salary and f.monthly_total and f.basic_salary / f.monthly_total < 0.5:
        return _r(
            "risk",
            "medium",
            "الأجر الأساسي أقل من نصف الحزمة، ما يخفض مكافأة نهاية الخدمة والتأمينات المحسوبة عليه.",
            "Basic wage is under half the package, which lowers end-of-service and GOSI amounts derived from it.",
        )
    return _r("ok", "low", "الأجر محدد بوضوح.", "The wage is clearly stated.")


def check_pay_date(f: ContractFacts, text: str):
    if not re.search(r"(موعد|تاريخ)\s*(صرف|دفع)|نهاية كل شهر|pay(?:ment)? date|end of each month", text, re.I):
        return _r("missing", "low", "موعد صرف الأجر غير محدد.", "The wage payment date is not specified.")
    return _r("ok", "low", "موعد صرف الأجر محدد.", "The wage payment date is specified.")


def check_medical(f: ContractFacts, text: str):
    if not f.mentions_medical_insurance:
        return _r("missing", "medium", "لا يوجد نص على التأمين الطبي.", "No medical insurance clause.")
    return _r("ok", "low", "التأمين الطبي مذكور.", "Medical insurance is addressed.")


def check_social_insurance(f: ContractFacts, text: str):
    if not f.mentions_social_insurance:
        return _r("missing", "low", "لا يوجد نص على التأمينات الاجتماعية.", "No social insurance clause.")
    return _r("ok", "low", "التأمينات الاجتماعية مذكورة.", "Social insurance is addressed.")


def check_non_compete(f: ContractFacts, text: str):
    if f.non_compete_months is None:
        return _r("ok", "low", "لا يوجد شرط عدم منافسة.", "No non-compete clause.")
    if f.non_compete_months > 24:
        return _r(
            "violation",
            "high",
            f"شرط عدم المنافسة {f.non_compete_months} شهرًا ويتجاوز الحد الأقصى (24 شهرًا).",
            f"The {f.non_compete_months}-month non-compete exceeds the 24-month ceiling.",
        )
    return _r(
        "risk",
        "medium",
        f"شرط عدم منافسة لمدة {f.non_compete_months} شهرًا. تأكد من تحديد المكان ونوع العمل.",
        f"A {f.non_compete_months}-month non-compete applies. Check that place and scope of work are limited.",
    )


def check_recruitment_fees(f: ContractFacts, text: str):
    if f.worker_pays_recruitment_fees:
        return _r(
            "violation",
            "critical",
            "العقد يحمّل العامل رسوم الاستقدام أو الإقامة، وهي على صاحب العمل.",
            "The contract puts recruitment or iqama fees on the worker; these are the employer's cost.",
        )
    return None


def check_waiver(f: ContractFacts, text: str):
    if re.search(r"يتنازل العامل|يسقط حق العامل|waives? (?:all|any) (?:rights|claims)", text, re.I):
        return _r(
            "risk",
            "high",
            "يوجد شرط تنازل عام عن حقوق. أي شرط ينتقص من الحقوق النظامية يقع باطلًا.",
            "There is a general waiver clause. Any term reducing statutory rights is void.",
        )
    return None


def check_contract_type(f: ContractFacts, text: str):
    if f.contract_type == "unknown":
        return _r(
            "missing",
            "medium",
            "نوع العقد (محدد المدة أو غير محدد) غير واضح.",
            "The contract type (fixed-term or open-ended) is unclear.",
        )
    return _r("ok", "low", f"نوع العقد: {f.contract_type}.", f"Contract type: {f.contract_type}.")


def check_job_description(f: ContractFacts, text: str):
    if not f.mentions_job_description:
        return _r("missing", "medium", "لا يوجد وصف للمهام الوظيفية.", "No job description or duties are stated.")
    return _r("ok", "low", "وصف المهام موجود.", "Job duties are described.")


def check_start_date(f: ContractFacts, text: str):
    if not f.mentions_start_date:
        return _r("missing", "low", "تاريخ المباشرة غير مذكور.", "The start date is not stated.")
    return _r("ok", "low", "تاريخ المباشرة مذكور.", "The start date is stated.")


def check_dispute(f: ContractFacts, text: str):
    if not f.mentions_dispute_resolution:
        return _r("missing", "low", "لا يوجد نص على جهة تسوية المنازعات.", "No dispute resolution clause.")
    return _r("ok", "low", "جهة تسوية المنازعات مذكورة.", "Dispute resolution is addressed.")


RULES: list[Rule] = [
    Rule("probation", "compliance", "فترة التجربة الحد الأقصى تسعين يوما", check_probation, "فترة التجربة", "Probation period"),
    Rule("notice", "termination", "مدة الإشعار قبل إنهاء العقد ستين يوما", check_notice, "مدة الإشعار", "Notice period"),
    Rule("annual_leave", "time_and_leave", "الإجازة السنوية واحد وعشرون يوما", check_annual_leave, "الإجازة السنوية", "Annual leave"),
    Rule("hours", "time_and_leave", "ساعات العمل ثماني ساعات يوميا ثمان وأربعون أسبوعيا", check_hours, "ساعات العمل", "Working hours"),
    Rule("overtime", "pay", "أجر العمل الإضافي خمسون بالمائة", check_overtime, "العمل الإضافي", "Overtime"),
    Rule("end_of_service", "termination", "مكافأة نهاية الخدمة نصف شهر عن كل سنة", check_end_of_service, "مكافأة نهاية الخدمة", "End-of-service award"),
    Rule("salary_stated", "pay", "الأجر المتفق عليه بيانات عقد العمل", check_salary_stated, "وضوح الأجر", "Wage clarity"),
    Rule("pay_date", "pay", "حماية الأجور موعد صرف الأجر", check_pay_date, "موعد الصرف", "Payment date"),
    Rule("medical", "benefits", "التأمين الطبي في عقد العمل", check_medical, "التأمين الطبي", "Medical insurance"),
    Rule("social_insurance", "benefits", "التأمينات الاجتماعية", check_social_insurance, "التأمينات الاجتماعية", "Social insurance"),
    Rule("non_compete", "compliance", "شرط عدم المنافسة سنتان", check_non_compete, "عدم المنافسة", "Non-compete"),
    Rule("recruitment_fees", "compliance", "رسوم الاستقدام ورخصة العمل على صاحب العمل", check_recruitment_fees, "رسوم الاستقدام", "Recruitment fees"),
    Rule("waiver", "compliance", "كل شرط يخالف النظام أو ينتقص من حقوق العامل باطل", check_waiver, "شروط التنازل", "Waiver clauses"),
    Rule("contract_type", "clarity", "عقد محدد المدة وغير محدد المدة", check_contract_type, "نوع العقد", "Contract type"),
    Rule("job_description", "clarity", "وصف العمل ونوعه ومكانه", check_job_description, "وصف المهام", "Job description"),
    Rule("start_date", "clarity", "تاريخ الالتحاق بالعمل", check_start_date, "تاريخ المباشرة", "Start date"),
    Rule("dispute", "clarity", "المحاكم العمالية تسوية المنازعات", check_dispute, "تسوية المنازعات", "Dispute resolution"),
]


class ContractAnalysisAgent(Agent):
    name = "contract_analysis"
    description = "Checks clauses against retrieved articles and scores the contract."

    def __init__(self, rag: RegulatoryRAGAgent | None = None) -> None:
        super().__init__()
        self.rag = rag or RegulatoryRAGAgent()

    def _score(self, findings: list[Finding]) -> tuple[dict, float]:
        scores = {dim: 100.0 for dim in DIMENSIONS}
        for finding in findings:
            if finding["status"] in ("violation", "risk", "missing"):
                penalty = PENALTY[finding["severity"]]
                if finding["status"] == "missing":
                    penalty *= 0.6
                elif finding["status"] == "risk":
                    penalty *= 0.8
                scores[finding["dimension"]] = max(0.0, scores[finding["dimension"]] - penalty)

        overall = sum(scores[d] * w for d, w in DIMENSIONS.items())

        # A contract with a void or unlawful term cannot present as a good deal
        # just because the rest of it is tidy. Cap the headline score.
        severities = {(f["status"], f["severity"]) for f in findings}
        if ("violation", "critical") in severities:
            overall = min(overall, 45.0)
        elif ("violation", "high") in severities:
            overall = min(overall, 70.0)
        elif any(status == "violation" for status, _ in severities):
            overall = min(overall, 80.0)
        scorecard = {
            dim: {
                "score": round(scores[dim], 1),
                "weight": DIMENSIONS[dim],
                "label_ar": DIMENSION_LABELS[dim][0],
                "label_en": DIMENSION_LABELS[dim][1],
            }
            for dim in DIMENSIONS
        }
        return scorecard, round(overall, 1)

    def _summary(self, facts: ContractFacts, findings: list[Finding], overall: float, locale: str) -> tuple[str, str]:
        violations = [f for f in findings if f["status"] == "violation"]
        risks = [f for f in findings if f["status"] == "risk"]
        missing = [f for f in findings if f["status"] == "missing"]

        ar = (
            f"التقييم العام {overall:.0f} من 100. "
            f"تم رصد {len(violations)} مخالفة و{len(risks)} بند عالي المخاطر و{len(missing)} بندًا ناقصًا."
        )
        en = (
            f"Overall score {overall:.0f}/100 with {len(violations)} violation(s), "
            f"{len(risks)} risky clause(s) and {len(missing)} missing clause(s)."
        )
        if violations:
            ar += " أهم ما يجب تعديله: " + "، ".join(v["title_ar"] for v in violations[:3]) + "."
            en += " Fix first: " + ", ".join(v["title_en"] for v in violations[:3]) + "."

        if llm.available:
            bullets = "\n".join(
                f"- [{f['status']}] {f['title_en']}: {f['detail_en']}" for f in findings if f["status"] != "ok"
            )
            drafted = llm.text(
                "You summarise an employment contract review for the worker who received the offer. "
                "Three sentences maximum. Plain language. Do not invent findings. "
                "Write Arabic first, then a line '---', then English.",
                f"Score: {overall}/100\nJob title: {facts.job_title}\nFindings:\n{bullets}",
            )
            if drafted and "---" in drafted:
                part_ar, _, part_en = drafted.partition("---")
                ar, en = part_ar.strip() or ar, part_en.strip() or en
                self.log("summarise", mode="llm")
        return ar, en

    def run(self, text: str, locale: str = "ar", facts: ContractFacts | None = None) -> dict:
        facts = facts or extract(text, locale)
        self.log("extract", source=facts.extraction_source)

        findings: list[Finding] = []
        for rule in RULES:
            outcome = rule.check(facts, text)
            if outcome is None:
                continue
            status, severity, detail_ar, detail_en = outcome
            hits = self.rag.retrieve([rule.query], k=2)
            from app.tools.citation_formatter import format_all

            findings.append(
                {
                    "id": rule.id,
                    "dimension": rule.dimension,
                    "title_ar": rule.title_ar,
                    "title_en": rule.title_en,
                    "status": status,
                    "severity": severity,
                    "detail_ar": detail_ar,
                    "detail_en": detail_en,
                    "citations": format_all(hits, locale)[:2],
                }
            )

        scorecard, overall = self._score(findings)
        violations = [f for f in findings if f["status"] == "violation"]
        missing = [f for f in findings if f["status"] == "missing"]

        blocking_missing = [f for f in missing if f["severity"] in ("critical", "high", "medium")]
        if violations:
            status = "non_compliant"
        elif overall >= 85 and not blocking_missing:
            status = "compliant"
        else:
            status = "needs_review"

        summary_ar, summary_en = self._summary(facts, findings, overall, locale)
        self.log("score", overall=overall, status=status, findings=len(findings))

        return {
            "facts": facts.to_dict(),
            "findings": findings,
            "missing_clauses": [
                {"id": f["id"], "title_ar": f["title_ar"], "title_en": f["title_en"], "severity": f["severity"]}
                for f in missing
            ],
            "scorecard": scorecard,
            "overall_score": overall,
            "compliance_status": status,
            "summary_ar": summary_ar,
            "summary_en": summary_en,
            "citations": [c for f in findings for c in f["citations"]],
            "trace": self.trace,
        }
