"""Shared agent contract.

Every agent is a plain class with a `name`, a `run()` entry point, and a
`trace` list it appends to so the orchestrator can show the user which agents
and tools were involved in an answer.
"""

from __future__ import annotations

from abc import ABC, abstractmethod
from typing import Any


class Agent(ABC):
    name: str = "agent"
    description: str = ""

    def __init__(self) -> None:
        self.trace: list[dict[str, Any]] = []

    def log(self, action: str, **detail: Any) -> None:
        self.trace.append({"agent": self.name, "action": action, **detail})

    @abstractmethod
    def run(self, *args: Any, **kwargs: Any) -> dict[str, Any]: ...


def pick(value_ar: str, value_en: str, locale: str) -> str:
    return value_ar if locale == "ar" else value_en
