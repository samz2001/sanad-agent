from __future__ import annotations

import logging
from contextlib import asynccontextmanager

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from app.api.routes import router
from app.config import settings
from app.db.database import init_db

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(name)s %(message)s")
log = logging.getLogger("sanad")


@asynccontextmanager
async def lifespan(app: FastAPI):
    init_db()
    from app.rag.vector_store import get_store

    store = get_store()
    log.info(
        "Sanad ready: mode=%s chunks=%d embedder=%s",
        "online" if settings.online else "offline",
        len(store.chunks),
        store.embedder.name if store.embedder else "none",
    )
    yield


app = FastAPI(
    title="Sanad API",
    version="0.1.0",
    description="Employment contract analysis, salary benchmarking and offer comparison for Saudi Arabia.",
    lifespan=lifespan,
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.cors_origin_list,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(router)


@app.get("/")
def root() -> dict:
    return {"service": "Sanad", "docs": "/docs"}
