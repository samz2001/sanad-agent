"""Current Regulation Checker.

Answers one question before any legal claim leaves the system: is the corpus we
are citing still the live version published by MHRSD?

Each corpus file declares `version`, `issued`, `last_verified` and
`source_status` in its front matter. This tool reports them, flags any document
that has not been verified within `STALE_AFTER_DAYS`, and flags anything still
marked `placeholder`. The Regulatory RAG agent attaches the result to every
answer so the user can see how fresh the ground truth is.
"""

from __future__ import annotations

from datetime import date, datetime
from pathlib import Path

from app.config import settings
from app.rag.chunking import _parse_front_matter

STALE_AFTER_DAYS = 90


def _parse_date(value: str) -> date | None:
    for fmt in ("%Y-%m-%d", "%Y/%m/%d", "%Y"):
        try:
            return datetime.strptime(value.strip(), fmt).date()
        except (ValueError, AttributeError):
            continue
    return None


def registry() -> list[dict]:
    docs = []
    for path in sorted(Path(settings.regulations_dir).glob("*.md")):
        meta, _ = _parse_front_matter(path.read_text(encoding="utf-8"))
        verified = _parse_date(meta.get("last_verified", ""))
        age = (date.today() - verified).days if verified else None
        docs.append(
            {
                "doc_id": meta.get("doc_id", path.stem),
                "title_ar": meta.get("title_ar", path.stem),
                "title_en": meta.get("title_en", path.stem),
                "version": meta.get("version", ""),
                "issued": meta.get("issued", ""),
                "last_verified": meta.get("last_verified", ""),
                "source_url": meta.get("source_url", ""),
                "source_status": meta.get("source_status", "unknown"),
                "days_since_verified": age,
                "stale": age is None or age > STALE_AFTER_DAYS,
            }
        )
    return docs


def check(doc_ids: list[str] | None = None) -> dict:
    docs = registry()
    if doc_ids:
        docs = [d for d in docs if d["doc_id"] in doc_ids]

    placeholders = [d["doc_id"] for d in docs if d["source_status"] != "official"]
    stale = [d["doc_id"] for d in docs if d["stale"]]

    if placeholders:
        confidence = "low"
    elif stale:
        confidence = "medium"
    else:
        confidence = "high"

    notices = []
    if placeholders:
        notices.append(
            {
                "level": "critical",
                "ar": "المصادر التالية ما زالت نسخًا تجريبية ولم تُستبدل بالوثائق الرسمية: "
                + "، ".join(placeholders),
                "en": "These sources are still placeholders and have not been replaced with the "
                "official MHRSD documents: " + ", ".join(placeholders),
            }
        )
    if stale:
        notices.append(
            {
                "level": "warning",
                "ar": f"لم يتم التحقق من تحديث {len(stale)} وثيقة خلال آخر {STALE_AFTER_DAYS} يومًا.",
                "en": f"{len(stale)} document(s) have not been re-verified in the last "
                f"{STALE_AFTER_DAYS} days.",
            }
        )

    return {
        "documents": docs,
        "confidence": confidence,
        "notices": notices,
        "checked_at": date.today().isoformat(),
    }
