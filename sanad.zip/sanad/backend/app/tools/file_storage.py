"""File Storage tool: keeps the original upload next to its extracted text.

Files are written under STORAGE_DIR/<user_id>/<document_id><ext>. Swap the two
functions for an S3 client and nothing else in the codebase changes.
"""

from __future__ import annotations

from pathlib import Path

from app.config import settings


def save(user_id: str, document_id: str, filename: str, data: bytes) -> str:
    suffix = Path(filename).suffix[:10]
    folder = Path(settings.storage_dir) / user_id
    folder.mkdir(parents=True, exist_ok=True)
    path = folder / f"{document_id}{suffix}"
    path.write_bytes(data)
    return str(path)


def load(stored_path: str) -> bytes:
    return Path(stored_path).read_bytes()


def delete(stored_path: str) -> None:
    Path(stored_path).unlink(missing_ok=True)
