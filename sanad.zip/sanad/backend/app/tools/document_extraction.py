"""Document Extraction tool: PDF / DOCX / JPEG / PNG / TXT -> structured text."""

from __future__ import annotations

import io
import re
from dataclasses import asdict, dataclass

from app.tools.ocr import ocr_image

ARABIC_RANGE = re.compile(r"[\u0600-\u06FF]")


@dataclass
class ExtractedDocument:
    text: str
    method: str
    language: str
    pages: int
    warnings: list[str]

    def to_dict(self) -> dict:
        return asdict(self)


def detect_language(text: str) -> str:
    letters = [c for c in text if c.isalpha()]
    if not letters:
        return "ar"
    arabic = sum(1 for c in letters if ARABIC_RANGE.match(c))
    return "ar" if arabic / len(letters) > 0.3 else "en"


def _clean(text: str) -> str:
    text = text.replace("\u200f", "").replace("\u200e", "")
    text = re.sub(r"[ \t]+", " ", text)
    text = re.sub(r"\n{3,}", "\n\n", text)
    return text.strip()


def _from_pdf(data: bytes) -> ExtractedDocument:
    from pypdf import PdfReader

    warnings: list[str] = []
    reader = PdfReader(io.BytesIO(data))
    parts = [(page.extract_text() or "") for page in reader.pages]
    text = _clean("\n\n".join(parts))
    method = "pdf-text"

    # A scanned contract yields almost no text layer. Fall back to OCR per page.
    if len(text) < 200:
        warnings.append("PDF has little or no text layer; used OCR.")
        try:
            import pypdfium2 as pdfium

            pdf = pdfium.PdfDocument(io.BytesIO(data))
            ocr_parts = []
            for i in range(len(pdf)):
                bitmap = pdf[i].render(scale=2)
                ocr_parts.append(ocr_image(bitmap.to_pil()))
            text = _clean("\n\n".join(ocr_parts))
            method = "pdf-ocr"
        except Exception as exc:  # noqa: BLE001
            warnings.append(f"OCR fallback failed: {exc}")

    return ExtractedDocument(text, method, detect_language(text), len(reader.pages), warnings)


def _from_docx(data: bytes) -> ExtractedDocument:
    import docx

    doc = docx.Document(io.BytesIO(data))
    parts = [p.text for p in doc.paragraphs]
    for table in doc.tables:
        for row in table.rows:
            parts.append(" | ".join(cell.text.strip() for cell in row.cells))
    text = _clean("\n".join(parts))
    return ExtractedDocument(text, "docx", detect_language(text), 1, [])


def _from_image(data: bytes) -> ExtractedDocument:
    from PIL import Image

    image = Image.open(io.BytesIO(data))
    text = _clean(ocr_image(image))
    warnings = [] if text else ["OCR returned no text. The image may be too low resolution."]
    return ExtractedDocument(text, "ocr", detect_language(text), 1, warnings)


def extract(data: bytes, filename: str, mime_type: str = "") -> ExtractedDocument:
    name = filename.lower()
    if name.endswith(".pdf") or mime_type == "application/pdf":
        return _from_pdf(data)
    if name.endswith((".docx", ".doc")) or "word" in mime_type:
        return _from_docx(data)
    if name.endswith((".png", ".jpg", ".jpeg", ".webp", ".tif", ".tiff")) or mime_type.startswith(
        "image/"
    ):
        return _from_image(data)
    text = _clean(data.decode("utf-8", errors="replace"))
    return ExtractedDocument(text, "plain-text", detect_language(text), 1, [])
