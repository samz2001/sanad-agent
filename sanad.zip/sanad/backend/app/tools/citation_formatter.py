"""Citation Formatter tool: turns a retrieved chunk into a document + article reference."""

from __future__ import annotations

from typing import Any


def format_citation(chunk: dict[str, Any], locale: str = "ar") -> dict[str, Any]:
    meta = chunk.get("metadata", chunk)
    title = meta.get("title_ar" if locale == "ar" else "title_en") or meta.get("title_ar", "")
    article = meta.get("article", "")
    if locale == "ar":
        label = f"{title} - المادة {article}" if article else title
    else:
        label = f"{title}, Article {article}" if article else title
    return {
        "label": label,
        "document": title,
        "article": article,
        "doc_id": meta.get("doc_id", ""),
        "version": meta.get("version", ""),
        "source_url": meta.get("source_url", ""),
        "source_status": meta.get("source_status", "unknown"),
        "excerpt": (chunk.get("text", "")[:400]).strip(),
    }


def format_all(chunks: list[dict[str, Any]], locale: str = "ar") -> list[dict[str, Any]]:
    seen, out = set(), []
    for chunk in chunks:
        citation = format_citation(chunk, locale)
        key = (citation["doc_id"], citation["article"])
        if key in seen:
            continue
        seen.add(key)
        out.append(citation)
    return out
