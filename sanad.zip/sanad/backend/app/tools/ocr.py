"""OCR tool. Arabic + English via Tesseract, with a clear error when it is missing."""

from __future__ import annotations

import logging
import shutil

log = logging.getLogger(__name__)

LANGS = "ara+eng"


def tesseract_available() -> bool:
    return shutil.which("tesseract") is not None


def ocr_image(image) -> str:
    """Run OCR on a PIL image. Returns an empty string if OCR is unavailable."""
    if not tesseract_available():
        log.warning("tesseract not installed; OCR skipped")
        return ""
    try:
        import pytesseract

        return pytesseract.image_to_string(image, lang=LANGS)
    except Exception:  # noqa: BLE001
        log.exception("OCR failed")
        return ""
