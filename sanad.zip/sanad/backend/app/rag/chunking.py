"""Loads the regulatory corpus and splits it into article-level chunks.

Each file in `data/regulations` is Markdown with a small YAML front matter block
and one `## المادة N` (or `## Article N`) heading per article. Article-level
chunks are what make citations exact: every retrieved passage already knows
which document and which article number it came from.
"""

from __future__ import annotations

import re
from dataclasses import dataclass, field
from pathlib import Path

FRONT_MATTER = re.compile(r"^---\n(.*?)\n---\n", re.DOTALL)
ARTICLE_HEADING = re.compile(r"^##\s+(?:المادة|Article)\s+([\w\u0660-\u0669/-]+)\s*(.*)$", re.M)

MAX_CHARS = 1400
OVERLAP = 200


@dataclass
class Chunk:
    id: str
    text: str
    metadata: dict = field(default_factory=dict)

    def to_dict(self) -> dict:
        return {"id": self.id, "text": self.text, "metadata": self.metadata}


def _parse_front_matter(raw: str) -> tuple[dict, str]:
    match = FRONT_MATTER.match(raw)
    if not match:
        return {}, raw
    meta = {}
    for line in match.group(1).splitlines():
        if ":" in line:
            key, _, value = line.partition(":")
            meta[key.strip()] = value.strip().strip('"')
    return meta, raw[match.end() :]


def _window(text: str) -> list[str]:
    if len(text) <= MAX_CHARS:
        return [text]
    out, start = [], 0
    while start < len(text):
        out.append(text[start : start + MAX_CHARS])
        start += MAX_CHARS - OVERLAP
    return out


def load_document(path: Path) -> list[Chunk]:
    raw = path.read_text(encoding="utf-8")
    meta, body = _parse_front_matter(raw)
    doc_id = meta.get("doc_id", path.stem)
    base_meta = {
        "doc_id": doc_id,
        "title_ar": meta.get("title_ar", path.stem),
        "title_en": meta.get("title_en", path.stem),
        "version": meta.get("version", ""),
        "issued": meta.get("issued", ""),
        "source_url": meta.get("source_url", ""),
        "source_status": meta.get("source_status", "unknown"),
        "authority": meta.get("authority", "MHRSD"),
    }

    matches = list(ARTICLE_HEADING.finditer(body))
    chunks: list[Chunk] = []
    if not matches:
        for i, part in enumerate(_window(body.strip())):
            chunks.append(Chunk(f"{doc_id}::p{i}", part, {**base_meta, "article": ""}))
        return chunks

    for i, match in enumerate(matches):
        end = matches[i + 1].start() if i + 1 < len(matches) else len(body)
        article = match.group(1)
        heading = match.group(2).strip()
        section = body[match.end() : end].strip()
        text = f"{base_meta['title_ar']} - المادة {article}\n{heading}\n{section}".strip()
        for j, part in enumerate(_window(text)):
            suffix = "" if j == 0 else f"#{j}"
            chunks.append(
                Chunk(
                    f"{doc_id}::{article}{suffix}",
                    part,
                    {**base_meta, "article": article, "heading": heading},
                )
            )
    return chunks


def load_corpus(folder: Path) -> list[Chunk]:
    chunks: list[Chunk] = []
    for path in sorted(Path(folder).glob("*.md")):
        chunks.extend(load_document(path))
    return chunks
