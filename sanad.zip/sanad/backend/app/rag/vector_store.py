"""Vector database for the regulatory knowledge base.

Two embedders share one interface:

* `OpenAIEmbedder`  - text-embedding-3-small, used when an API key is configured.
* `TfidfEmbedder`   - character n-gram TF-IDF fitted on the corpus. No key, no
  network, works well on Arabic morphology, and keeps retrieval deterministic
  for tests.

The index is a NumPy matrix of L2-normalised vectors plus a JSON sidecar, so
search is a single dot product. Swap this class for pgvector or Qdrant later
without touching the agents.
"""

from __future__ import annotations

import json
import pickle
from pathlib import Path
from typing import Protocol

import numpy as np

from app.config import settings
from app.llm.client import llm
from app.rag.chunking import Chunk


class Embedder(Protocol):
    name: str

    def fit(self, texts: list[str]) -> None: ...
    def encode(self, texts: list[str]) -> np.ndarray: ...


class TfidfEmbedder:
    name = "tfidf-char"

    def __init__(self) -> None:
        from sklearn.feature_extraction.text import TfidfVectorizer

        self.vectorizer = TfidfVectorizer(
            analyzer="char_wb", ngram_range=(2, 4), min_df=1, sublinear_tf=True, max_features=60000
        )
        self._fitted = False

    def fit(self, texts: list[str]) -> None:
        self.vectorizer.fit(texts)
        self._fitted = True

    def encode(self, texts: list[str]) -> np.ndarray:
        if not self._fitted:
            raise RuntimeError("TfidfEmbedder.fit must run before encode")
        return np.asarray(self.vectorizer.transform(texts).todense(), dtype=np.float32)


class OpenAIEmbedder:
    name = "openai"

    def fit(self, texts: list[str]) -> None:  # nothing to fit
        return None

    def encode(self, texts: list[str]) -> np.ndarray:
        vectors: list[list[float]] = []
        for i in range(0, len(texts), 64):
            batch = llm.embed(texts[i : i + 64])
            if batch is None:
                raise RuntimeError("embedding provider unavailable")
            vectors.extend(batch)
        return np.asarray(vectors, dtype=np.float32)


def _normalise(matrix: np.ndarray) -> np.ndarray:
    norms = np.linalg.norm(matrix, axis=1, keepdims=True)
    norms[norms == 0] = 1.0
    return matrix / norms


class VectorStore:
    def __init__(self, path: Path | str | None = None) -> None:
        self.path = Path(path or settings.vector_index_path)
        self.chunks: list[dict] = []
        self.matrix: np.ndarray | None = None
        self.embedder: Embedder | None = None

    # ---------- build / persist ----------

    def build(self, chunks: list[Chunk], embedder: Embedder | None = None) -> None:
        self.embedder = embedder or (OpenAIEmbedder() if llm.available else TfidfEmbedder())
        texts = [c.text for c in chunks]
        self.embedder.fit(texts)
        self.matrix = _normalise(self.embedder.encode(texts))
        self.chunks = [c.to_dict() for c in chunks]

    def save(self) -> None:
        self.path.mkdir(parents=True, exist_ok=True)
        np.save(self.path / "vectors.npy", self.matrix)
        (self.path / "chunks.json").write_text(
            json.dumps(self.chunks, ensure_ascii=False), encoding="utf-8"
        )
        with open(self.path / "embedder.pkl", "wb") as fh:
            pickle.dump(self.embedder, fh)

    def load(self) -> bool:
        try:
            self.matrix = np.load(self.path / "vectors.npy")
            self.chunks = json.loads((self.path / "chunks.json").read_text(encoding="utf-8"))
            with open(self.path / "embedder.pkl", "rb") as fh:
                self.embedder = pickle.load(fh)
            return True
        except (FileNotFoundError, OSError, pickle.PickleError):
            return False

    @property
    def ready(self) -> bool:
        return self.matrix is not None and bool(self.chunks)

    # ---------- query ----------

    def search(self, query: str, k: int = 6, doc_ids: list[str] | None = None) -> list[dict]:
        if not self.ready:
            return []
        vector = _normalise(self.embedder.encode([query]))[0]
        scores = self.matrix @ vector

        order = np.argsort(-scores)
        results = []
        for idx in order:
            chunk = self.chunks[int(idx)]
            if doc_ids and chunk["metadata"].get("doc_id") not in doc_ids:
                continue
            results.append({**chunk, "score": round(float(scores[idx]), 4)})
            if len(results) >= k:
                break
        return results

    def multi_search(self, queries: list[str], k_each: int = 4, k_total: int = 8) -> list[dict]:
        """Retrieve for several sub-queries and merge, keeping the best score per chunk."""
        best: dict[str, dict] = {}
        for query in queries:
            for hit in self.search(query, k=k_each):
                current = best.get(hit["id"])
                if current is None or hit["score"] > current["score"]:
                    best[hit["id"]] = hit
        return sorted(best.values(), key=lambda h: -h["score"])[:k_total]


_store: VectorStore | None = None


def get_store() -> VectorStore:
    """Process-wide singleton. Builds the index on first use if none is saved."""
    global _store
    if _store is not None:
        return _store

    store = VectorStore()
    if not store.load():
        from app.rag.chunking import load_corpus

        chunks = load_corpus(settings.regulations_dir)
        if chunks:
            store.build(chunks)
            store.save()
    _store = store
    return _store


def reset_store() -> None:
    global _store
    _store = None
