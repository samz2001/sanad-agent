from functools import lru_cache
from pathlib import Path

from pydantic_settings import BaseSettings, SettingsConfigDict

BASE_DIR = Path(__file__).resolve().parent.parent


class Settings(BaseSettings):
    model_config = SettingsConfigDict(env_file=".env", extra="ignore")

    app_name: str = "Sanad"
    openai_api_key: str = ""
    openai_chat_model: str = "gpt-4o-mini"
    openai_embedding_model: str = "text-embedding-3-small"

    database_url: str = f"sqlite:///{BASE_DIR / 'sanad.db'}"
    storage_dir: Path = BASE_DIR / "storage"
    vector_index_path: Path = BASE_DIR / "storage" / "vector_index"
    regulations_dir: Path = BASE_DIR / "data" / "regulations"
    salary_data_path: Path = BASE_DIR / "data" / "salary_benchmarks.csv"

    cors_origins: str = "http://localhost:5173,http://127.0.0.1:5173"

    @property
    def online(self) -> bool:
        """True when a real model provider is configured."""
        return bool(self.openai_api_key.strip())

    @property
    def cors_origin_list(self) -> list[str]:
        return [o.strip() for o in self.cors_origins.split(",") if o.strip()]


@lru_cache
def get_settings() -> Settings:
    s = Settings()
    s.storage_dir.mkdir(parents=True, exist_ok=True)
    Path(s.vector_index_path).parent.mkdir(parents=True, exist_ok=True)
    return s


settings = get_settings()
