"""Thin wrapper around the model provider.

Sanad is designed to run in two modes:

* **online**  - OPENAI_API_KEY is set, chat completions and embeddings go to OpenAI.
* **offline** - no key. `available` is False and every agent falls back to its
  deterministic rule engine, so the whole pipeline still runs end to end. This
  keeps demos, CI and local development working without spending tokens.
"""

from __future__ import annotations

import json
import logging
from typing import Any

from app.config import settings

log = logging.getLogger(__name__)


class LLMClient:
    def __init__(self) -> None:
        self._client = None
        if settings.online:
            from openai import OpenAI

            self._client = OpenAI(api_key=settings.openai_api_key)

    @property
    def available(self) -> bool:
        return self._client is not None

    def text(self, system: str, user: str, temperature: float = 0.2) -> str | None:
        if not self.available:
            return None
        try:
            resp = self._client.chat.completions.create(
                model=settings.openai_chat_model,
                temperature=temperature,
                messages=[
                    {"role": "system", "content": system},
                    {"role": "user", "content": user},
                ],
            )
            return resp.choices[0].message.content
        except Exception:  # noqa: BLE001 - never let a provider error break a request
            log.exception("chat completion failed")
            return None

    def json(self, system: str, user: str, temperature: float = 0.0) -> dict[str, Any] | None:
        """Ask for a strict JSON object. Returns None on any failure."""
        if not self.available:
            return None
        try:
            resp = self._client.chat.completions.create(
                model=settings.openai_chat_model,
                temperature=temperature,
                response_format={"type": "json_object"},
                messages=[
                    {"role": "system", "content": system + "\nRespond with a single JSON object."},
                    {"role": "user", "content": user},
                ],
            )
            return json.loads(resp.choices[0].message.content)
        except Exception:  # noqa: BLE001
            log.exception("json completion failed")
            return None

    def embed(self, texts: list[str]) -> list[list[float]] | None:
        if not self.available:
            return None
        try:
            resp = self._client.embeddings.create(
                model=settings.openai_embedding_model, input=texts
            )
            return [d.embedding for d in resp.data]
        except Exception:  # noqa: BLE001
            log.exception("embedding call failed")
            return None


llm = LLMClient()
