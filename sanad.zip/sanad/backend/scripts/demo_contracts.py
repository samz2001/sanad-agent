"""Generate two sample contracts and run the whole pipeline over them.

    python -m scripts.demo_contracts
"""

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from app.db.database import SessionLocal, init_db  # noqa: E402
from app.services import analyse_document, compare_analyses, store_document  # noqa: E402

OFFER_A = """
عقد عمل
صاحب العمل: شركة الأفق للتقنية
المسمى الوظيفي: محلل أمن سيبراني
مكان العمل: الرياض
نوع العقد: محدد المدة، مدة العقد سنة واحدة
تاريخ المباشرة: 2026-10-01
الأجر الأساسي: 11000 ريال شهريا
بدل السكن: 2500 ريال
بدل النقل: 800 ريال
فترة التجربة: 180 يوما
ساعات العمل: 9 ساعات يوميا، ستة أيام في الأسبوع
الإجازة السنوية: 18 يوما
الإشعار قبل الإنهاء: 30 يوما
يتحمل العامل رسوم الاستقدام ورخصة العمل.
وصف العمل: مراقبة الأنظمة والاستجابة للحوادث.
"""

OFFER_B = """
عقد عمل
صاحب العمل: مجموعة سند للأنظمة
المسمى الوظيفي: أخصائي حوكمة ومخاطر والتزام
مكان العمل: الرياض
نوع العقد: غير محدد المدة
تاريخ المباشرة: 2026-11-01
الأجر الأساسي: 14000 ريال شهريا
بدل السكن: 3500 ريال
بدل النقل: 1000 ريال
مكافأة سنوية مرتبطة بالأداء.
فترة التجربة: 90 يوما
ساعات العمل: 8 ساعات يوميا، 40 ساعة في الأسبوع
الإجازة السنوية: 25 يوما
الإشعار قبل الإنهاء: 60 يوما
التأمين الطبي: يشمل العامل وأسرته.
التأمينات الاجتماعية مطبقة وفق النظام.
العمل الإضافي يُدفع وفق نظام العمل.
مكافأة نهاية الخدمة وفق نظام العمل.
يحق للعامل العمل عن بعد يومين أسبوعيا.
ميزانية تدريب سنوية وشهادات مهنية.
تسوية المنازعات أمام المحاكم العمالية.
وصف العمل: بناء برنامج الالتزام وإدارة المخاطر.
"""


def main() -> None:
    init_db()
    session = SessionLocal()
    user_id = "demo-user"
    ids = []
    for label, text in [("عرض الأفق", OFFER_A), ("عرض سند", OFFER_B)]:
        document = store_document(
            session, user_id, f"{label}.txt", text.encode("utf-8"), label=label, keep_file=False
        )
        analysis = analyse_document(session, document)
        ids.append(analysis.id)
        print(f"{label}: {analysis.overall_score}/100 ({analysis.compliance_status})")
        for finding in analysis.findings:
            if finding["status"] != "ok":
                print(f"  [{finding['status']}/{finding['severity']}] {finding['title_ar']}: {finding['detail_ar']}")

    comparison = compare_analyses(session, user_id, ids)
    print("\nRecommendation:", comparison.result["recommended_label"])
    print(comparison.result["explanation_ar"])
    session.close()


if __name__ == "__main__":
    main()
