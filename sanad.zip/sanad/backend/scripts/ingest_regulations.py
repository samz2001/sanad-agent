"""Rebuild the regulatory vector index from data/regulations.

    python -m scripts.ingest_regulations
"""

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from app.config import settings  # noqa: E402
from app.rag.chunking import load_corpus  # noqa: E402
from app.rag.vector_store import VectorStore  # noqa: E402
from app.tools import regulation_checker  # noqa: E402


def main() -> None:
    chunks = load_corpus(settings.regulations_dir)
    if not chunks:
        raise SystemExit(f"No regulation files found in {settings.regulations_dir}")

    store = VectorStore()
    store.build(chunks)
    store.save()
    print(f"Indexed {len(chunks)} article chunks with {store.embedder.name}")

    status = regulation_checker.check()
    print(f"Corpus confidence: {status['confidence']}")
    for notice in status["notices"]:
        print(f"  [{notice['level']}] {notice['en']}")


if __name__ == "__main__":
    main()
