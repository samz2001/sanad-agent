---
doc_id: unified_contract
title_ar: نموذج عقد العمل الموحد
title_en: Unified Employment Contract Template
authority: MHRSD
version: "placeholder-0.1"
issued: "2021-01-01"
last_verified: "2026-09-13"
source_url: https://www.hrsd.gov.sa/
source_status: placeholder
---

> نسخة تجريبية للتطوير فقط. Placeholder for development only.

## المادة 1
البيانات الأساسية: اسم صاحب العمل ورقم السجل التجاري وعنوانه، واسم العامل
وجنسيته ورقم هويته وعنوانه ووسيلة التواصل معه.
EN: Required identity fields for employer and worker.

## المادة 2
المسمى الوظيفي ووصف العمل ومكان أدائه، ونوع العقد (محدد المدة أو غير محدد) وتاريخ
بدايته ومدته.
EN: Job title, description, place of work, contract type, start date and term.

## المادة 3
الأجر الأساسي والبدلات (السكن، النقل، غيرها) ودورية الصرف والعملة، وأي مكافآت أو
عمولات وشروط استحقاقها.
EN: Basic wage, allowances, pay frequency and currency, bonuses and commissions.

## المادة 4
ساعات العمل وأيام الراحة الأسبوعية والإجازة السنوية والإجازات الأخرى.
EN: Working hours, weekly rest, annual leave and other leave.

## المادة 5
فترة التجربة إن وجدت ومدتها، وشروط الإنهاء ومدة الإشعار لكلا الطرفين.
EN: Probation, termination conditions and notice period for both parties.

## المادة 6
التأمين الطبي والتأمينات الاجتماعية وتذاكر السفر للعامل غير السعودي إن استحقت.
EN: Medical insurance, social insurance, and travel tickets where applicable.

## المادة 7
تسوية المنازعات: تختص المحاكم العمالية بالنظر في الخلافات الناشئة عن هذا العقد
وفق أحكام نظام العمل.
EN: Disputes fall to the labor courts under the Labor Law.
