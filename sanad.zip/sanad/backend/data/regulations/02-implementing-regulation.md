---
doc_id: implementing_regulation
title_ar: اللائحة التنفيذية لنظام العمل
title_en: Implementing Regulation of the Labor Law
authority: MHRSD
version: "placeholder-0.1"
issued: "2019-01-01"
last_verified: "2026-09-13"
source_url: https://www.hrsd.gov.sa/
source_status: placeholder
---

> نسخة تجريبية للتطوير فقط. استبدلها باللائحة التنفيذية الرسمية.
> Placeholder for development only.

## المادة 3
تلتزم المنشأة بإعداد لائحة تنظيم عمل تتضمن قواعد تنظيم العمل والجزاءات، وتعتمد
من الوزارة، وتُعلن في مكان ظاهر.
EN: Establishments must adopt an approved, published work-organisation bylaw.

## المادة 8
يُحسب الأجر الفعلي شاملًا الأجر الأساسي وما يضاف إليه من بدلات وعلاوات مستحقة
بصفة دورية، ويستخدم في احتساب الحقوق النهائية.
EN: The actual wage includes basic wage plus regular allowances and is the basis
for end-of-service entitlements.

## المادة 12
يجب توثيق عقد العمل إلكترونيًا في المنصة المعتمدة، ولا يخل عدم التوثيق بحقوق
العامل المقررة نظامًا.
EN: Contracts must be documented electronically; failure to document does not
reduce the worker's statutory rights.

## المادة 15
لا يجوز تضمين عقد العمل شرطًا يخالف أحكام نظام العمل أو ينتقص من حقوق العامل،
ويقع باطلًا كل شرط كهذا ولو كان سابقًا على العمل بالنظام.
EN: Any contract term that contradicts the Labor Law or reduces statutory
worker rights is void.
