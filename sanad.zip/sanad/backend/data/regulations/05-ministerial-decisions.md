---
doc_id: ministerial_decisions
title_ar: القرارات الوزارية ذات الصلة
title_en: Relevant Ministerial Decisions
authority: MHRSD
version: "placeholder-0.1"
issued: "2023-01-01"
last_verified: "2026-09-13"
source_url: https://www.hrsd.gov.sa/
source_status: placeholder
---

> نسخة تجريبية للتطوير فقط. Placeholder for development only.

## المادة 1
حماية الأجور: تلتزم المنشآت برفع ملفات الأجور شهريًا عبر نظام حماية الأجور،
وصرف الأجر في موعده المحدد في العقد.
EN: Wage Protection System filing and on-time wage payment obligations.

## المادة 2
العمل عن بُعد: يجوز الاتفاق على أداء العمل كليًا أو جزئيًا عن بُعد مع بقاء جميع
حقوق العامل النظامية قائمة.
EN: Remote work may be agreed in whole or in part without reducing statutory
rights.

## المادة 3
شرط عدم المنافسة: لا يزيد على سنتين من تاريخ انتهاء العلاقة، ويجب أن يكون مكتوبًا
ومحددًا من حيث الزمان والمكان ونوع العمل.
EN: A non-compete may not exceed two years and must be written and limited in
time, place and type of work.

## المادة 4
نقل الخدمات والتنقل الوظيفي وفق ضوابط مبادرة تحسين العلاقة التعاقدية.
EN: Service transfer and job mobility under the Labor Reform Initiative.
