---
doc_id: labor_law
title_ar: نظام العمل السعودي
title_en: Saudi Labor Law
authority: MHRSD
version: "placeholder-0.1"
issued: "2005-09-27"
last_verified: "2026-09-13"
source_url: https://www.hrsd.gov.sa/
source_status: placeholder
---

> **تنبيه:** هذا الملف نسخة تجريبية مختصرة أُعدت لتشغيل النظام أثناء التطوير.
> يجب استبداله بنص نظام العمل الرسمي المنشور من وزارة الموارد البشرية والتنمية
> الاجتماعية قبل أي استخدام حقيقي. أرقام المواد هنا للاسترشاد فقط.
>
> **Notice:** placeholder summary for development only. Replace with the official
> MHRSD text before any real use. Article numbers are indicative.

## المادة 37
يجب أن يكون عقد عمل غير السعودي مكتوبًا ومحدد المدة، وإذا خلا من بيان المدة تُعد
مدة رخصة العمل هي مدة العقد.
EN: A non-Saudi worker's contract must be written and fixed-term; if no term is
stated, the work permit period is treated as the contract term.

## المادة 50
عقد العمل هو عقد مبرم بين صاحب عمل وعامل يتعهد فيه العامل بأن يعمل تحت إدارة
صاحب العمل أو إشرافه مقابل أجر.
EN: Definition of the employment contract: work under the employer's direction
and supervision in return for a wage.

## المادة 51
يحرر العقد من نسختين، لكل طرف نسخة، ويجب أن يتضمن اسم صاحب العمل ومكانه واسم
العامل وجنسيته وما يلزم لإثبات شخصيته ومحل إقامته والأجر المتفق عليه ونوع العمل
ومكانه وتاريخ الالتحاق به ومدته إن كان محدد المدة.
EN: The contract is made in two copies and must state employer and worker
identity, agreed wage, type and place of work, start date and term.

## المادة 53
إذا كان العامل خاضعًا لفترة تجربة وجب النص على ذلك صراحة في عقد العمل وتحديدها
بوضوح بما لا يزيد على تسعين يومًا، ولا تدخل في حسابها إجازة عيدي الفطر والأضحى
والإجازة المرضية. يجوز تمديدها باتفاق مكتوب بما لا يتجاوز مائة وثمانين يومًا.
EN: A probation period must be stated expressly and may not exceed 90 days,
extendable in writing up to 180 days.

## المادة 58
لا يجوز لصاحب العمل أن يكلف العامل بعمل يختلف جوهريًا عن العمل المتفق عليه دون
موافقة العامل الكتابية، إلا في حالات الضرورة ولمدة لا تتجاوز ثلاثين يومًا في السنة.
EN: The worker may not be assigned substantially different work without written
consent, except in necessity for no more than 30 days per year.

## المادة 74
ينتهي عقد العمل باتفاق الطرفين، أو بانتهاء المدة المحددة، أو بناءً على إرادة أحد
الطرفين في العقود غير محددة المدة وفق الأحكام النظامية، أو ببلوغ سن التقاعد، أو
بالقوة القاهرة.
EN: Grounds on which an employment contract ends.

## المادة 75
في العقود غير محددة المدة يجوز لأي من الطرفين إنهاؤه بسبب مشروع مع إشعار كتابي
قبل الإنهاء بستين يومًا إذا كان الأجر شهريًا، وثلاثين يومًا لغيره.
EN: Open-ended contracts may be terminated for a valid reason with 60 days'
written notice for monthly-paid workers, 30 days otherwise.

## المادة 77
إذا أُنهي العقد لسبب غير مشروع استحق الطرف المتضرر تعويضًا: أجر خمسة عشر يومًا عن
كل سنة خدمة في العقد غير محدد المدة، أو أجر المدة المتبقية في العقد محدد المدة،
ولا يقل التعويض عن أجر شهرين.
EN: Compensation for unlawful termination; minimum two months' wages.

## المادة 80
يجوز لصاحب العمل فسخ العقد دون مكافأة أو إشعار أو تعويض في حالات محددة حصرًا،
منها الاعتداء على صاحب العمل، وعدم الوفاء بالالتزامات الجوهرية، والغياب دون سبب
مشروع أكثر من ثلاثين يومًا في السنة أو خمسة عشر يومًا متتالية بعد الإنذار.
EN: Exhaustive grounds for dismissal without award, notice or compensation.

## المادة 84
إذا انتهت علاقة العمل وجب على صاحب العمل أن يدفع للعامل مكافأة نهاية الخدمة
بواقع أجر نصف شهر عن كل سنة من السنوات الخمس الأولى، وأجر شهر عن كل سنة تالية،
ويتخذ الأجر الأخير أساسًا لحسابها، ويستحق العامل مكافأة عن أجزاء السنة بنسبة ما
قضاه منها في العمل.
EN: End-of-service award: half a month's wage per year for the first five years,
one month per subsequent year, computed on the last wage, pro-rated.

## المادة 98
لا يجوز تشغيل العامل تشغيلًا فعليًا أكثر من ثماني ساعات في اليوم، أو ثمانٍ
وأربعين ساعة في الأسبوع، وتخفض إلى ست ساعات يوميًا في شهر رمضان للمسلمين.
EN: Maximum 8 hours per day / 48 per week; 6 hours per day in Ramadan for Muslim
workers.

## المادة 104
يوم الجمعة هو يوم الراحة الأسبوعية لجميع العمال، ولا تقل الراحة الأسبوعية عن
أربع وعشرين ساعة متتالية.
EN: Friday is the weekly rest day; weekly rest is at least 24 consecutive hours.

## المادة 107
يدفع صاحب العمل للعامل عن ساعات العمل الإضافية أجرًا إضافيًا يوازي أجر الساعة
مضافًا إليه خمسون بالمائة من أجره الأساسي.
EN: Overtime is paid at the hourly wage plus 50 percent of the basic wage.

## المادة 109
يستحق العامل إجازة سنوية مدفوعة الأجر لا تقل عن واحد وعشرين يومًا، تُزاد إلى
ثلاثين يومًا إذا أمضى العامل في خدمة صاحب العمل خمس سنوات متصلة.
EN: Paid annual leave of at least 21 days, rising to 30 days after five
continuous years of service.

## المادة 117
يستحق العامل الذي يثبت مرضه إجازة مرضية بأجر كامل عن الثلاثين يومًا الأولى،
وبثلاثة أرباع الأجر عن الستين يومًا التالية، ودون أجر عن الثلاثين يومًا التي
تلي ذلك، خلال السنة الواحدة.
EN: Sick leave in a single year: 30 days at full pay, next 60 days at three
quarters, following 30 days unpaid.

## المادة 151
للعاملة الحق في إجازة وضع بأجر كامل لمدة اثني عشر أسبوعًا توزعها كيف تشاء، على
ألا تعمل بأي حال خلال الأسابيع الستة التالية مباشرة للوضع.
EN: Maternity leave of 12 weeks at full pay; no work in the six weeks
immediately after delivery.

## المادة 155
لا يجوز لصاحب العمل فصل العاملة أو إنذارها بالفصل أثناء تمتعها بإجازة الوضع.
EN: A female worker may not be dismissed or given notice during maternity leave.
