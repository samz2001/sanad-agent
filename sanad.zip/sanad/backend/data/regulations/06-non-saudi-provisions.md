---
doc_id: non_saudi_provisions
title_ar: أحكام استخدام غير السعوديين
title_en: Provisions for Non-Saudi Employees
authority: MHRSD
version: "placeholder-0.1"
issued: "2005-09-27"
last_verified: "2026-09-13"
source_url: https://www.hrsd.gov.sa/
source_status: placeholder
---

> نسخة تجريبية للتطوير فقط. Placeholder for development only.

## المادة 33
لا يجوز لغير السعودي ممارسة العمل إلا بعد الحصول على رخصة عمل من الوزارة، ووفق
شروط منها دخول البلاد بطريقة مشروعة وامتلاك المؤهلات التي تحتاجها البلاد.
EN: Non-Saudis require a ministry work permit and lawful entry.

## المادة 39
لا يجوز لصاحب العمل أن يترك عامله يعمل لدى الغير، ولا يجوز للعامل العمل لدى
صاحب عمل آخر، ولا يجوز لصاحب العمل توظيف عامل غيره.
EN: Prohibition on lending workers or working for another employer.

## المادة 40
يتحمل صاحب العمل رسوم استقدام العامل غير السعودي ورسوم رخصة الإقامة ورخصة العمل
وتجديدهما وما يترتب على التأخير، ورسوم تغيير المهنة والخروج والعودة، وتذكرة عودة
العامل إلى موطنه بعد انتهاء العلاقة.
EN: The employer bears recruitment, iqama and work permit fees, profession
change and exit/re-entry fees, and the return ticket home.
