---
doc_id: flexible_work
title_ar: تنظيم العمل المرن
title_en: Flexible Work Regulation
authority: MHRSD
version: "placeholder-0.1"
issued: "2020-01-01"
last_verified: "2026-09-13"
source_url: https://www.hrsd.gov.sa/
source_status: placeholder
---

> نسخة تجريبية للتطوير فقط. Placeholder for development only.

## المادة 2
العمل المرن عقد عمل مؤقت يعمل بموجبه العامل بالساعة، ويستحق أجرًا عن كل ساعة عمل
فعلية، ولا تزيد ساعات العمل على خمس وتسعين ساعة في الشهر.
EN: Flexible work is hourly temporary work paid per actual hour, capped at 95
hours per month.

## المادة 4
لا يستحق العامل بالساعة مكافأة نهاية الخدمة ولا الإجازة السنوية، ويُدرج مقابلها
ضمن الأجر بالساعة.
EN: Hourly flexible workers do not accrue end-of-service award or annual leave;
these are folded into the hourly rate.

## المادة 6
يجب توثيق عقد العمل المرن إلكترونيًا وتسجيل ساعات العمل الفعلية.
EN: Flexible work contracts must be documented electronically with actual hours
logged.
