"""End-to-end smoke test. Runs entirely offline: no API key required."""

import io
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

import pytest
from fastapi.testclient import TestClient

from app.main import app
from scripts.demo_contracts import OFFER_A, OFFER_B

HEADERS = {"X-User-Id": "test-user"}


@pytest.fixture(scope="module")
def client():
    with TestClient(app) as test_client:
        yield test_client


def _upload(client, name, text):
    return client.post(
        "/api/documents",
        headers=HEADERS,
        files={"file": (name, io.BytesIO(text.encode("utf-8")), "text/plain")},
        data={"label": name, "analyse": "true"},
    )


def test_health(client):
    body = client.get("/api/health").json()
    assert body["status"] == "ok"
    assert body["index_ready"] is True


def test_regulation_currency_is_reported(client):
    body = client.get("/api/regulations").json()
    assert body["confidence"] in {"low", "medium", "high"}
    assert len(body["documents"]) >= 6


def test_upload_analyses_and_compares(client):
    first = _upload(client, "offer-a.txt", OFFER_A).json()
    second = _upload(client, "offer-b.txt", OFFER_B).json()

    assert first["analysis"]["compliance_status"] == "non_compliant"
    assert any(f["id"] == "recruitment_fees" for f in first["analysis"]["findings"])
    assert second["analysis"]["overall_score"] > first["analysis"]["overall_score"]

    # every finding carries at least one article citation
    assert all(f["citations"] for f in first["analysis"]["findings"])

    compared = client.post(
        "/api/compare",
        headers=HEADERS,
        json={
            "analysis_ids": [first["analysis"]["id"], second["analysis"]["id"]],
            "weights": {"pay": 0.4, "compliance": 0.3, "growth": 0.3},
        },
    ).json()
    assert compared["recommended"] == second["analysis"]["id"]
    assert len(compared["offers"]) == 2


def test_chat_routes_to_agents(client):
    regulatory = client.post(
        "/api/chat",
        headers=HEADERS,
        json={"message": "كم مدة الإجازة السنوية في نظام العمل؟", "session_id": "s1"},
    ).json()
    assert regulatory["intent"] == "regulatory_question"
    assert regulatory["citations"]

    salary = client.post(
        "/api/chat",
        headers=HEADERS,
        json={"message": "هل راتبي مناسب لسوق العمل؟", "session_id": "s1"},
    ).json()
    assert salary["intent"] == "salary_question"

    compare = client.post(
        "/api/chat",
        headers=HEADERS,
        json={"message": "قارن بين العرضين", "session_id": "s1"},
    ).json()
    assert compare["intent"] == "compare_offers"
    assert compare["data"]["comparison"]["recommended_label"]


def test_salary_benchmark_returns_a_range(client):
    body = client.post(
        "/api/salary/benchmark",
        json={"job_title": "Security Analyst", "city": "Riyadh", "offered_salary": 9000},
    ).json()
    assert body["benchmark"]["found"] is True
    assert body["benchmark"]["p25"] < body["benchmark"]["p75"]
    assert body["placement"]["verdict"] in {"below", "within", "above"}
