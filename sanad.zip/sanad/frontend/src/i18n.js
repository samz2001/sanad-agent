export const strings = {
  ar: {
    dir: 'rtl',
    brand: 'سند',
    tagline: 'دليلك لعمل عادل ومطابق للنظام',
    heroLead: 'ارفع عقد العمل قبل أن توقّعه.',
    heroBody:
      'سند يقرأ العقد، يقارنه بمواد نظام العمل، ويخبرك بما ينقصه وما يخالفه، ثم يضع أجره في نطاق السوق.',
    upload: 'ارفع عقدًا',
    uploadCv: 'ارفع السيرة الذاتية',
    uploading: 'جارٍ القراءة والتحليل…',
    consent: 'احفظ نسخة من العقد لتحسين نطاقات الرواتب',
    consentHint: 'بدون الموافقة يُقرأ النص ولا يُحفظ الملف.',
    offers: 'العروض',
    noOffers: 'لا توجد عروض بعد. ابدأ برفع عقد.',
    score: 'التقييم',
    outOf: 'من 100',
    statusLabels: {
      compliant: 'مطابق',
      needs_review: 'يحتاج مراجعة',
      non_compliant: 'مخالف',
      unknown: 'غير محدد'
    },
    findingStatus: {
      violation: 'مخالفة',
      risk: 'مخاطرة',
      missing: 'بند ناقص',
      ok: 'سليم'
    },
    scorecard: 'بطاقة التقييم',
    findings: 'الملاحظات',
    salary: 'الأجر مقابل السوق',
    offered: 'الأجر في العرض',
    range: 'النطاق المرجعي',
    source: 'المصدر',
    verdicts: {
      below: 'أقل من النطاق',
      within: 'ضمن النطاق',
      above: 'أعلى من النطاق',
      unknown: 'غير محدد'
    },
    compare: 'المفاضلة',
    comparePrompt: 'اختر عرضين لتبدأ المقارنة.',
    priorities: 'أولوياتك',
    runCompare: 'قارن العرضين',
    recommended: 'العرض الموصى به',
    tradeoffs: 'ما تخسره مقابل ذلك',
    closeCall: 'الفارق ضيق.',
    ask: 'اسأل سند',
    askPlaceholder: 'مثال: كم مدة الإشعار قبل إنهاء العقد؟',
    send: 'إرسال',
    sources: 'المواد المستند إليها',
    corpusTitle: 'حالة مصادر الأنظمة',
    factors: {
      pay: 'الأجر',
      compliance: 'الالتزام',
      benefits: 'المزايا',
      growth: 'النمو',
      flexibility: 'المرونة',
      stability: 'الاستقرار'
    },
    disclaimer:
      'سند أداة مساعدة وليست استشارة قانونية. راجع النص الرسمي أو مختصًا قبل أي قرار.',
    emptyReport: 'اختر عرضًا من القائمة لعرض تقريره.',
    error: 'تعذر إكمال الطلب. تأكد من تشغيل الخادم ثم أعد المحاولة.'
  },
  en: {
    dir: 'ltr',
    brand: 'Sanad',
    tagline: 'Your guide to fair and compliant employment',
    heroLead: 'Read the contract before you sign it.',
    heroBody:
      'Sanad reads the contract, checks it against the labor law articles, tells you what is missing or unlawful, and places the pay in a market range.',
    upload: 'Upload a contract',
    uploadCv: 'Upload a CV',
    uploading: 'Reading and analysing…',
    consent: 'Keep a copy to improve salary ranges',
    consentHint: 'Without consent the text is read but the file is not stored.',
    offers: 'Offers',
    noOffers: 'No offers yet. Start by uploading a contract.',
    score: 'Score',
    outOf: 'of 100',
    statusLabels: {
      compliant: 'Compliant',
      needs_review: 'Needs review',
      non_compliant: 'Non-compliant',
      unknown: 'Unknown'
    },
    findingStatus: {
      violation: 'Violation',
      risk: 'Risk',
      missing: 'Missing',
      ok: 'Clear'
    },
    scorecard: 'Scorecard',
    findings: 'Findings',
    salary: 'Pay against the market',
    offered: 'Offered',
    range: 'Reference range',
    source: 'Source',
    verdicts: {
      below: 'Below range',
      within: 'Within range',
      above: 'Above range',
      unknown: 'Unknown'
    },
    compare: 'Compare',
    comparePrompt: 'Pick two offers to compare.',
    priorities: 'Your priorities',
    runCompare: 'Compare offers',
    recommended: 'Recommended offer',
    tradeoffs: 'What you give up',
    closeCall: 'The gap is narrow.',
    ask: 'Ask Sanad',
    askPlaceholder: 'For example: how much notice is required before termination?',
    send: 'Send',
    sources: 'Articles relied on',
    corpusTitle: 'Regulatory source status',
    factors: {
      pay: 'Pay',
      compliance: 'Compliance',
      benefits: 'Benefits',
      growth: 'Growth',
      flexibility: 'Flexibility',
      stability: 'Stability'
    },
    disclaimer:
      'Sanad is a support tool, not legal advice. Check the official text or a professional before deciding.',
    emptyReport: 'Pick an offer from the list to see its report.',
    error: 'The request did not complete. Check that the server is running and try again.'
  }
}
