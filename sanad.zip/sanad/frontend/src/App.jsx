import { useCallback, useEffect, useMemo, useState } from 'react'
import { api } from './api.js'
import { strings } from './i18n.js'
import UploadBar from './components/UploadBar.jsx'
import OfferList from './components/OfferList.jsx'
import Report from './components/Report.jsx'
import Compare from './components/Compare.jsx'
import Ask from './components/Ask.jsx'
import CorpusStatus from './components/CorpusStatus.jsx'

export default function App() {
  const [locale, setLocale] = useState('ar')
  const [analyses, setAnalyses] = useState([])
  const [selectedId, setSelectedId] = useState(null)
  const [report, setReport] = useState(null)
  const [corpus, setCorpus] = useState(null)
  const [view, setView] = useState('report')
  const [busy, setBusy] = useState(false)
  const [error, setError] = useState(null)

  const t = strings[locale]

  useEffect(() => {
    document.documentElement.lang = locale
    document.documentElement.dir = t.dir
  }, [locale, t.dir])

  const refresh = useCallback(async () => {
    try {
      const [list, status] = await Promise.all([api.analyses(), api.regulations()])
      setAnalyses(list)
      setCorpus(status)
      if (!selectedId && list.length) setSelectedId(list[0].id)
    } catch {
      setError(t.error)
    }
  }, [selectedId, t.error])

  useEffect(() => {
    refresh()
  }, []) // eslint-disable-line react-hooks/exhaustive-deps

  useEffect(() => {
    if (!selectedId) return setReport(null)
    api
      .analysis(selectedId)
      .then(setReport)
      .catch(() => setError(t.error))
  }, [selectedId, t.error])

  async function handleUpload(file, { kind, consent }) {
    setBusy(true)
    setError(null)
    try {
      const result = await api.upload(file, { kind, consent, locale })
      const list = await api.analyses()
      setAnalyses(list)
      if (result.analysis) {
        setSelectedId(result.analysis.id)
        setView('report')
      }
    } catch {
      setError(t.error)
    } finally {
      setBusy(false)
    }
  }

  const canCompare = analyses.length >= 2

  const tabs = useMemo(
    () => [
      { id: 'report', label: t.findings },
      { id: 'compare', label: t.compare, disabled: !canCompare },
      { id: 'ask', label: t.ask }
    ],
    [t, canCompare]
  )

  return (
    <div className="shell">
      <header className="masthead">
        <div className="mark">
          <span className="mark__glyph" aria-hidden="true">
            س
          </span>
          <div>
            <h1>{t.brand}</h1>
            <p>{t.tagline}</p>
          </div>
        </div>
        <button className="locale" onClick={() => setLocale(locale === 'ar' ? 'en' : 'ar')}>
          {locale === 'ar' ? 'English' : 'العربية'}
        </button>
      </header>

      {!analyses.length && (
        <section className="hero">
          <p className="hero__lead">{t.heroLead}</p>
          <p className="hero__body">{t.heroBody}</p>
        </section>
      )}

      <UploadBar t={t} busy={busy} onUpload={handleUpload} />
      {error && <p className="notice notice--breach">{error}</p>}
      <CorpusStatus t={t} corpus={corpus} locale={locale} />

      <main className="workspace">
        <OfferList
          t={t}
          analyses={analyses}
          selectedId={selectedId}
          onSelect={(id) => {
            setSelectedId(id)
            setView('report')
          }}
          locale={locale}
        />

        <section className="panel">
          <nav className="tabs">
            {tabs.map((tab) => (
              <button
                key={tab.id}
                className={view === tab.id ? 'tab tab--on' : 'tab'}
                disabled={tab.disabled}
                onClick={() => setView(tab.id)}
              >
                {tab.label}
              </button>
            ))}
          </nav>

          {view === 'report' && <Report t={t} locale={locale} report={report} />}
          {view === 'compare' && <Compare t={t} locale={locale} analyses={analyses} />}
          {view === 'ask' && <Ask t={t} locale={locale} />}
        </section>
      </main>

      <footer className="footer">
        <p>{t.disclaimer}</p>
      </footer>
    </div>
  )
}
