export default function OfferList({ t, analyses, selectedId, onSelect, locale }) {
  return (
    <aside className="offers">
      <h2 className="offers__title">{t.offers}</h2>
      {!analyses.length && <p className="muted">{t.noOffers}</p>}
      <ul>
        {analyses.map((analysis) => (
          <li key={analysis.id}>
            <button
              className={analysis.id === selectedId ? 'offer offer--on' : 'offer'}
              onClick={() => onSelect(analysis.id)}
            >
              <span className="offer__name">{analysis.label || analysis.id.slice(0, 8)}</span>
              <span className={`offer__score offer__score--${analysis.compliance_status}`}>
                {Math.round(analysis.overall_score)}
              </span>
              <span className="offer__status">{t.statusLabels[analysis.compliance_status]}</span>
            </button>
          </li>
        ))}
      </ul>
    </aside>
  )
}
