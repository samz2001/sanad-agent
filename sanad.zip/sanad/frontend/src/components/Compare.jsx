import { useState } from 'react'
import { api } from '../api.js'

const FACTORS = ['pay', 'compliance', 'benefits', 'growth', 'flexibility', 'stability']
const DEFAULTS = { pay: 30, compliance: 20, benefits: 15, growth: 15, flexibility: 10, stability: 10 }

export default function Compare({ t, locale, analyses }) {
  const [picked, setPicked] = useState(analyses.slice(0, 2).map((a) => a.id))
  const [weights, setWeights] = useState(DEFAULTS)
  const [result, setResult] = useState(null)
  const [busy, setBusy] = useState(false)

  function toggle(id) {
    setPicked((current) =>
      current.includes(id) ? current.filter((x) => x !== id) : [...current, id].slice(-2)
    )
  }

  async function run() {
    if (picked.length < 2) return
    setBusy(true)
    try {
      setResult(await api.compare(picked, weights, locale))
    } finally {
      setBusy(false)
    }
  }

  return (
    <div className="compare">
      <div className="compare__picks">
        {analyses.map((analysis) => (
          <button
            key={analysis.id}
            className={picked.includes(analysis.id) ? 'chip chip--on' : 'chip'}
            onClick={() => toggle(analysis.id)}
          >
            {analysis.label || analysis.id.slice(0, 8)}
          </button>
        ))}
      </div>

      <h3 className="section">{t.priorities}</h3>
      <div className="weights">
        {FACTORS.map((factor) => (
          <label key={factor} className="weight">
            <span>{t.factors[factor]}</span>
            <input
              type="range"
              min="0"
              max="50"
              value={weights[factor]}
              onChange={(e) => setWeights({ ...weights, [factor]: Number(e.target.value) })}
            />
            <span className="weight__value">{weights[factor]}</span>
          </label>
        ))}
      </div>

      <button className="button button--solid" onClick={run} disabled={picked.length < 2 || busy}>
        {t.runCompare}
      </button>

      {picked.length < 2 && <p className="muted">{t.comparePrompt}</p>}

      {result && (
        <div className="verdict">
          <p className="verdict__lead">
            <span className="verdict__label">{t.recommended}</span>
            <strong>{result.recommended_label}</strong>
          </p>
          <p>{locale === 'ar' ? result.explanation_ar : result.explanation_en}</p>

          <table className="matrix">
            <thead>
              <tr>
                <th />
                {result.offers.map((offer) => (
                  <th key={offer.analysis_id}>{offer.label}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {FACTORS.map((factor) => (
                <tr key={factor}>
                  <th scope="row">{t.factors[factor]}</th>
                  {result.offers.map((offer) => {
                    const best = Math.max(...result.offers.map((o) => o.factors[factor]))
                    const value = offer.factors[factor]
                    return (
                      <td key={offer.analysis_id} className={value === best ? 'matrix__best' : ''}>
                        {Math.round(value)}
                      </td>
                    )
                  })}
                </tr>
              ))}
              <tr className="matrix__total">
                <th scope="row">{t.score}</th>
                {result.offers.map((offer) => (
                  <td key={offer.analysis_id}>{Math.round(offer.weighted_score)}</td>
                ))}
              </tr>
            </tbody>
          </table>

          {result.tradeoffs.length > 0 && (
            <>
              <h3 className="section">{t.tradeoffs}</h3>
              <ul className="tradeoffs">
                {result.tradeoffs.map((tradeoff) => (
                  <li key={tradeoff.factor}>
                    {locale === 'ar' ? tradeoff.text_ar : tradeoff.text_en}
                  </li>
                ))}
              </ul>
            </>
          )}
        </div>
      )}
    </div>
  )
}
