export default function CorpusStatus({ t, corpus, locale }) {
  if (!corpus || !corpus.notices?.length) return null
  return (
    <section className={`notice notice--${corpus.confidence === 'low' ? 'breach' : 'flag'}`}>
      <strong>{t.corpusTitle}</strong>
      <ul>
        {corpus.notices.map((notice, index) => (
          <li key={index}>{locale === 'ar' ? notice.ar : notice.en}</li>
        ))}
      </ul>
    </section>
  )
}
