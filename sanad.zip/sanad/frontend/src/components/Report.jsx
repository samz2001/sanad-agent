import { useState } from 'react'

const ORDER = { violation: 0, risk: 1, missing: 2, ok: 3 }

function Stamp({ t, report }) {
  const status = report.compliance_status
  return (
    <div className={`stamp stamp--${status}`}>
      <span className="stamp__score">{Math.round(report.overall_score)}</span>
      <span className="stamp__of">{t.outOf}</span>
      <span className="stamp__status">{t.statusLabels[status]}</span>
    </div>
  )
}

function Scorecard({ t, locale, scorecard }) {
  return (
    <div className="scorecard">
      {Object.entries(scorecard).map(([key, dimension]) => (
        <div className="dim" key={key}>
          <div className="dim__head">
            <span>{locale === 'ar' ? dimension.label_ar : dimension.label_en}</span>
            <span className="dim__value">{Math.round(dimension.score)}</span>
          </div>
          <div className="dim__track">
            <div className="dim__fill" style={{ inlineSize: `${dimension.score}%` }} />
          </div>
        </div>
      ))}
    </div>
  )
}

function Finding({ t, locale, finding }) {
  const [open, setOpen] = useState(false)
  const detail = locale === 'ar' ? finding.detail_ar : finding.detail_en
  const title = locale === 'ar' ? finding.title_ar : finding.title_en
  return (
    <li className={`finding finding--${finding.status}`}>
      <button className="finding__head" onClick={() => setOpen(!open)} aria-expanded={open}>
        <span className="finding__tag">{t.findingStatus[finding.status]}</span>
        <span className="finding__title">{title}</span>
      </button>
      <p className="finding__detail">{detail}</p>
      {open && finding.citations?.length > 0 && (
        <div className="citations">
          <span className="citations__label">{t.sources}</span>
          {finding.citations.map((citation, index) => (
            <div className="citation" key={index}>
              <span className="citation__label">{citation.label}</span>
              <p>{citation.excerpt}</p>
            </div>
          ))}
        </div>
      )}
    </li>
  )
}

function Salary({ t, locale, salary }) {
  if (!salary?.benchmark) return null
  const { benchmark, placement, offered_salary: offered } = salary
  if (!benchmark.found) {
    return <p className="muted">{locale === 'ar' ? salary.message_ar : salary.message_en}</p>
  }
  const span = benchmark.p75 - benchmark.p25 || 1
  const marker = offered
    ? Math.min(100, Math.max(0, ((offered - benchmark.p25) / span) * 100))
    : null

  return (
    <div className="salary">
      <div className="salary__row">
        <span>{t.offered}</span>
        <strong>{offered ? `${Math.round(offered).toLocaleString()} ${benchmark.currency}` : '—'}</strong>
      </div>
      <div className="salary__scale">
        <div className="salary__band" />
        {marker !== null && <div className="salary__marker" style={{ insetInlineStart: `${marker}%` }} />}
      </div>
      <div className="salary__ticks">
        <span>{Math.round(benchmark.p25).toLocaleString()}</span>
        <span>{Math.round(benchmark.p50).toLocaleString()}</span>
        <span>{Math.round(benchmark.p75).toLocaleString()}</span>
      </div>
      <p className={`salary__verdict salary__verdict--${placement.verdict}`}>
        {t.verdicts[placement.verdict]}
      </p>
      <p className="muted">
        {t.source}: {benchmark.source} · {benchmark.match} · {benchmark.city}
      </p>
    </div>
  )
}

export default function Report({ t, locale, report }) {
  if (!report) return <p className="muted">{t.emptyReport}</p>

  const findings = [...(report.findings ?? [])].sort(
    (a, b) => ORDER[a.status] - ORDER[b.status]
  )

  return (
    <article className="report">
      <header className="report__head">
        <div>
          <h2>{report.label}</h2>
          <p className="report__summary">{locale === 'ar' ? report.summary_ar : report.summary_en}</p>
        </div>
        <Stamp t={t} report={report} />
      </header>

      <h3 className="section">{t.scorecard}</h3>
      <Scorecard t={t} locale={locale} scorecard={report.scorecard ?? {}} />

      <h3 className="section">{t.salary}</h3>
      <Salary t={t} locale={locale} salary={report.salary} />

      <h3 className="section">{t.findings}</h3>
      <ul className="findings">
        {findings.map((finding) => (
          <Finding key={finding.id} t={t} locale={locale} finding={finding} />
        ))}
      </ul>
    </article>
  )
}
