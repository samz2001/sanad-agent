import { useState } from 'react'
import { api } from '../api.js'

export default function Ask({ t, locale }) {
  const [message, setMessage] = useState('')
  const [thread, setThread] = useState([])
  const [busy, setBusy] = useState(false)

  async function send() {
    const text = message.trim()
    if (!text || busy) return
    setThread((current) => [...current, { role: 'user', content: text }])
    setMessage('')
    setBusy(true)
    try {
      const response = await api.chat(text, locale)
      setThread((current) => [
        ...current,
        { role: 'assistant', content: response.reply, citations: response.citations, intent: response.intent }
      ])
    } catch {
      setThread((current) => [...current, { role: 'assistant', content: t.error }])
    } finally {
      setBusy(false)
    }
  }

  return (
    <div className="ask">
      <ul className="thread">
        {thread.map((turn, index) => (
          <li key={index} className={`turn turn--${turn.role}`}>
            <p>{turn.content}</p>
            {turn.citations?.length > 0 && (
              <div className="citations">
                <span className="citations__label">{t.sources}</span>
                {turn.citations.slice(0, 4).map((citation, i) => (
                  <div className="citation" key={i}>
                    <span className="citation__label">{citation.label}</span>
                    <p>{citation.excerpt}</p>
                  </div>
                ))}
              </div>
            )}
          </li>
        ))}
      </ul>
      <div className="composer">
        <input
          value={message}
          onChange={(e) => setMessage(e.target.value)}
          onKeyDown={(e) => e.key === 'Enter' && send()}
          placeholder={t.askPlaceholder}
        />
        <button className="button button--solid" onClick={send} disabled={busy}>
          {t.send}
        </button>
      </div>
    </div>
  )
}
