import { useRef, useState } from 'react'

export default function UploadBar({ t, busy, onUpload }) {
  const contractInput = useRef(null)
  const cvInput = useRef(null)
  const [consent, setConsent] = useState(false)

  function pick(ref, kind) {
    ref.current.onchange = (event) => {
      const file = event.target.files?.[0]
      if (file) onUpload(file, { kind, consent })
      event.target.value = ''
    }
    ref.current.click()
  }

  return (
    <section className="uploadbar">
      <div className="uploadbar__actions">
        <button className="button button--solid" disabled={busy} onClick={() => pick(contractInput, 'contract')}>
          {busy ? t.uploading : t.upload}
        </button>
        <button className="button" disabled={busy} onClick={() => pick(cvInput, 'cv')}>
          {t.uploadCv}
        </button>
      </div>
      <label className="consent">
        <input type="checkbox" checked={consent} onChange={(e) => setConsent(e.target.checked)} />
        <span>
          {t.consent}
          <em>{t.consentHint}</em>
        </span>
      </label>
      <input ref={contractInput} type="file" accept=".pdf,.docx,.png,.jpg,.jpeg,.txt" hidden />
      <input ref={cvInput} type="file" accept=".pdf,.docx,.png,.jpg,.jpeg,.txt" hidden />
    </section>
  )
}
