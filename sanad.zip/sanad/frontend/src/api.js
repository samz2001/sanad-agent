const BASE = import.meta.env.VITE_API_BASE ?? '/api'
const USER_ID = 'demo-user'

async function request(path, options = {}) {
  const response = await fetch(`${BASE}${path}`, {
    ...options,
    headers: {
      'X-User-Id': USER_ID,
      ...(options.body instanceof FormData ? {} : { 'Content-Type': 'application/json' }),
      ...(options.headers ?? {})
    }
  })
  if (!response.ok) {
    const detail = await response.text()
    throw new Error(detail || `Request failed with ${response.status}`)
  }
  return response.json()
}

export const api = {
  health: () => request('/health'),
  regulations: () => request('/regulations'),
  analyses: () => request('/analyses'),
  analysis: (id) => request(`/analyses/${id}`),
  upload: (file, { label, kind = 'contract', consent = false, locale = 'ar' }) => {
    const form = new FormData()
    form.append('file', file)
    form.append('label', label ?? file.name)
    form.append('kind', kind)
    form.append('consent_store', String(consent))
    form.append('locale', locale)
    return request('/documents', { method: 'POST', body: form })
  },
  compare: (analysisIds, weights, locale) =>
    request('/compare', {
      method: 'POST',
      body: JSON.stringify({ analysis_ids: analysisIds, weights, locale })
    }),
  chat: (message, locale, sessionId = 'web') =>
    request('/chat', {
      method: 'POST',
      body: JSON.stringify({ message, locale, session_id: sessionId })
    })
}
