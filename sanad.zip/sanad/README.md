# Sanad

AI-powered employment contract analysis, salary benchmarking and offer comparison for Saudi Arabia.

The code implements the architecture in the system design: a supervisor agent in front of four
specialist agents, a tool layer, a regulatory vector index, and a relational application store.

```
User (web, Arabic/English)
        |
Orchestrator  ->  intent analysis / task routing / context management / response synthesis
        |
        +-- 1. Regulatory RAG agent      (retrieves articles, cites document + article number)
        +-- 2. Contract analysis agent   (rule engine + fixed-dimension scorecard)
        +-- 3. Salary & CV agent         (benchmark range, offer positioning)
        +-- 4. Comparison agent          (weighted ranking, trade-offs, recommendation)
        |
Tools:  document extraction, OCR, file storage, regulation checker, citation formatter
Data:   regulatory vector index, salary benchmark table, application database
```

## Run it

Requires Python 3.11+, Node 20+, and `tesseract-ocr` with the Arabic pack for scanned documents.

```bash
cd backend
pip install -r requirements.txt
cp .env.example .env
python -m scripts.ingest_regulations     # build the vector index
uvicorn app.main:app --reload --port 8000
```

```bash
cd frontend
npm install
npm run dev                              # http://localhost:5173, proxies /api to :8000
```

Or the whole stack with Postgres:

```bash
OPENAI_API_KEY=sk-... docker compose up --build    # app on http://localhost:8080
```

## Offline mode

With no `OPENAI_API_KEY`, every agent still runs. Retrieval falls back to a character n-gram
TF-IDF index, extraction and analysis use their rule engines, and summaries use templates.
Set the key and the same pipeline routes intent classification, fact extraction, answer
synthesis and summaries through the model instead.

That means `make test` and `make demo` work on any machine, and a demo never fails because of
a rate limit.

```bash
make demo      # analyses two sample contracts and compares them
make test      # end-to-end API smoke tests
```

## What the analysis produces

Every contract gets the same six scored dimensions, which is what makes two offers comparable:
compliance, pay, hours and leave, termination, benefits, clarity.

Each finding is one of:

| status | meaning |
| --- | --- |
| `violation` | the clause contradicts a statutory minimum |
| `risk` | lawful but works against the worker |
| `missing` | a required or expected clause is absent |
| `ok` | present and at or above the minimum |

Findings carry the retrieved article they were judged against, so nothing in the report is an
unsourced assertion. A critical violation caps the headline score at 45 regardless of how tidy
the rest of the contract is.

## Before this touches a real user

**The regulatory corpus in `backend/data/regulations` is placeholder text.** It is short
summaries written to exercise the pipeline, not the official documents. Every file declares
`source_status: placeholder`, the Current Regulation Checker reports corpus confidence as `low`
while any placeholder remains, and the UI shows that banner to the user.

To replace it, drop the real MHRSD documents into `backend/data/regulations` as Markdown with
one `## المادة N` heading per article, set `source_status: official` plus `version`, `issued`,
`source_url` and `last_verified` in the front matter, then run `make index`.

The salary table in `backend/data/salary_benchmarks.csv` is likewise illustrative and needs the
GASTAT extract. The "trusted online sources" fallback from the architecture is left as
`SalaryCVAgent._web_lookup`, unimplemented on purpose: scraping unverified pay figures into a
range a user negotiates against is worse than saying there is no range.

## Layout

```
backend/
  app/
    orchestrator.py          supervisor agent
    agents/                  the four agents + contract fact extraction
    rag/                     chunking and the vector store
    tools/                   extraction, OCR, storage, regulation checker, citations
    api/routes.py            REST surface
    services.py              pipelines shared by routes and orchestrator
    db/                      SQLAlchemy models and session
  data/regulations/          the corpus, one file per document
  scripts/                   ingest, demo
  tests/                     end-to-end smoke tests
frontend/
  src/components/            upload, offer list, report, compare, ask
  src/i18n.js                Arabic and English strings, RTL by default
```

## API

| method | path | purpose |
| --- | --- | --- |
| GET | `/api/health` | mode, index size, embedder |
| POST | `/api/documents` | upload a contract or CV, analyse on arrival |
| GET | `/api/analyses`, `/api/analyses/{id}` | stored reports |
| POST | `/api/compare` | rank two or more offers with user weights |
| POST | `/api/salary/benchmark` | range and positioning for a role |
| GET | `/api/regulations` | corpus versions and staleness |
| POST | `/api/regulations/ask` | cited answer from the corpus |
| POST | `/api/chat` | orchestrated turn, routed to the right agents |

Auth is a stand-in: requests carry `X-User-Id`. Replace `app/api/deps.py:current_user` with real
token verification before deployment.

## Privacy

Uploads are stored only when the user ticks consent. Without it the file is never written to
disk, only the extracted text needed to answer in that session. `DELETE /api/documents/{id}`
removes both.

Sanad is a support tool, not legal advice, and the UI says so on every screen.
